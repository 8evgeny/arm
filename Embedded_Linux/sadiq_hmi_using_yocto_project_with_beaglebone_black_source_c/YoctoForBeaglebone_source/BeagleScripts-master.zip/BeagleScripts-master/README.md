# BeagleScripts
Initially we have two scripts
1) prepare_card.sh for formating SD card.
2) copy_images.sh for copying latest images from tmp/deploy to SD card.
