#include "board.h"

int main()
{
	//инициализация отладочной платы
	BRD_init();
	//инициализация светодиодов
	Init_LEDS_Port();
	while(1)
	{
		BRD_LED_setState(brdLed1);
		HAL_SYS_WaitMs(250);
		BRD_LED_resetState(brdLed1);
		BRD_LED_setState(brdLed2);
		HAL_SYS_WaitMs(250);
		BRD_LED_resetState(brdLed2);
		BRD_LED_setState(brdLed3);
		HAL_SYS_WaitMs(250);
		BRD_LED_resetState(brdLed3);
		BRD_LED_setState(brdLed4);
		HAL_SYS_WaitMs(250);
		BRD_LED_resetState(brdLed4);
	}
}
