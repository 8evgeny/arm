#include "board.h"
#include "5101HB015.h"
#include "5101HB015_SPI_1967VC3.h"

#define 		ADC_DMA_BUF_SIZE		2048
#define 		ADC_BUF_SIZE		    2*ADC_DMA_BUF_SIZE

static void adc_init(void);
static void link_dma_init(void);

unsigned int adc_dma_buf[ADC_DMA_BUF_SIZE]__attribute__((aligned(4))); //буфер c данными АЦП (каждое слово данных (32 бита) содежит 2 отсчета АЦП)
int adc_result_buf[ADC_BUF_SIZE]__attribute__((aligned(4))); //буфер c данными АЦП после перепаковки
static uint32_t link_dma_rx_tcb[4]__attribute__((aligned(4))); //буфер для записи конфигурации TCB

unsigned int adc_dma_done = 0;

static void repack_adc_data_short(unsigned int *data_in, int *data_out, unsigned int count);


__attribute__((interrupt))
static void DMA_LINK_RX_Handler (void) //обработчик прерывания DMA от LINK порта АЦП
{
	if (!adc_dma_done) //если флаг готовности был сброшен
	{
		adc_dma_done = 1; //установка флага готовности данных АЦП
		BRD_LED_toggleState(brdLed1);
	}

}

int main()
{

	//инициализация отладочной платы
	BRD_init();
	//инициализация светодиодов
	Init_LEDS_Port();
	//инициализация АЦП по SPI
	adc_init();
	//инициализация LINK-порта и DMA
	link_dma_init();

	//настройка LINK-портов

	while(1)
	{
		while(!adc_dma_done){} //ожидание завершения работы DMA
			adc_dma_done = 0;

		//перепаковка данных от АЦП (получаем от DMA в одном 32-битном слове по два отчета АЦП)
		repack_adc_data_short(adc_dma_buf, adc_result_buf, ADC_DMA_BUF_SIZE);


	}
}
//инициализация АЦП 0 и 1 по spi
static void adc_init(void)
{
	ADC5101HB015_config_t adc_cfg; //структура для записи конфигурации АЦП
	ADC5101HB015_hw_config_t adc_spi_cfg[2]; //структура для настройки SPI АЦП


	//задание выводов SPI интерфейса АЦП 0 и 1
	adc_spi_cfg[0].port = LX_GPIO_PC;
	adc_spi_cfg[0].cs_bit = (1 << 2);			// FLAG[2]
	adc_spi_cfg[0].clk_bit = (1 << 0);			// FLAG[0]
	adc_spi_cfg[0].mosi_bit = (1 << 3);			// FLAG[3]
	adc_spi_cfg[0].miso_bit = (1 << 3);
	adc_spi_cfg[0].power_down_bit = (1 << 24);	// L0ACKO
	adc_spi_cfg[0].core_freq_khz = CORE_FREQ_KHZ;

	adc_spi_cfg[1].port = LX_GPIO_PC;
	adc_spi_cfg[1].cs_bit = (1 << 2);			// FLAG[2]
	adc_spi_cfg[1].clk_bit = (1 << 1);			// FLAG[1]
	adc_spi_cfg[1].mosi_bit = (1 << 3);			// FLAG[3]
	adc_spi_cfg[1].miso_bit = (1 << 3);
	adc_spi_cfg[1].power_down_bit = (1 << 28);	// L1ACKO
	adc_spi_cfg[1].core_freq_khz = CORE_FREQ_KHZ;

	//задание значений регистров АЦП
	adc_cfg.reference_level = ADC5101HB015_REF_1P0;
	adc_cfg.output_format = ADC5101HB015_OUTPUT_LVDS;
	adc_cfg.lvdsen_pin_state = ADC5101HB015_LVDSEN_PIN_HIGH;
	adc_cfg.lvds_current_mode = ADC5101HB015_LVDS_CURRENT_NORMAL;
	adc_cfg.oen_pin_override = ADC5101HB015_OEN_OVERRIDE;
	adc_cfg.common_mode_sel = ADC5101HB015_COMMON_MODE_0P75;

	//инициализация АЦП 0 и 1 (сброс, калибровка, отправка конфигурации регистров по spi)
	ADC5101HB015_init(1, 1, &adc_spi_cfg[0]);
	ADC5101HB015_config(&adc_cfg);

	ADC5101HB015_init(1, 1, &adc_spi_cfg[1]);
	ADC5101HB015_config(&adc_cfg);
}
//инициализация LINK-интерфейса для работы с АЦП 0
static void link_dma_init(void)
{
	LinkRx_Init_type link_adc_ini_str; //структура для описания внешенего устройства с LINK интерфейсом (от кого принимаем)
    LinkRxEx_type  link_rx_ini_str; ///структура для инициализации приемника LINK порта

	uint32_t dma_ch_num; //номер канала dma c с которым работает АЦП

	//Деинициализация приемника LINK порта  0
	HAL_LinkRx_Disable(0);

	link_rx_ini_str.AdcDataSize = Link_AdcDataSize_14b;
	link_rx_ini_str.Rcode = Link_Rcode_En;
	link_rx_ini_str.BitOrder = Link_BitOrder_OddFrontEvenCut;
	link_rx_ini_str.GpsClk = Link_GpsClk_Dis;
	link_rx_ini_str.RxDest = Link_RxDest_Buff;

	link_adc_ini_str.DataSize = Link_DataSize_8bit;
	link_adc_ini_str.CheckBCMPI = Link_CheckBCMP_Dis;
	link_adc_ini_str.CheckSum = Link_CheckSum_Dis;
	link_adc_ini_str.OVRIntEn = Link_OvrIT_Dis;
	link_adc_ini_str.TOIntEn = Link_TOIT_Dis;

	//инициализация приемника LINK порта  0
	HAL_LinkRx_Enable(0, &link_adc_ini_str,  &link_rx_ini_str);

	dma_ch_num = 8; // канал 9 для АЦП 1
					// канал 9 для АЦП 0
	//деиницализация  LINK_DMA_RX_CH - канала DMA
	HAL_DMA_Stop(dma_ch_num);
	//Очистка источника опроса DMA_DAC_RX_CH - канала
	HAL_DMA_RqstClr(dma_ch_num);

	//установка нового источника оспроса для канала dma_ch_num,  dmaSTD
	HAL_DMA_RqstSet(dma_ch_num, dmaSTD);


	// конфигурация регистра TCB DMA
	link_dma_rx_tcb[0] = (unsigned int)&adc_dma_buf;
	link_dma_rx_tcb[1] = (ADC_DMA_BUF_SIZE << 16) | 4;
	link_dma_rx_tcb[2] = 0;
	link_dma_rx_tcb[3] = TCB_INTMEM | TCB_QUAD | TCB_CHAIN |TCB_INT | ((unsigned int )&link_dma_rx_tcb >> 2) | HAL_DMA_GetTCBChannelDest(dma_ch_num);

	//разрешение прерывания от канла DMA 8, передача указателя на функцию обработчик прерывания
	HAL_Interrupt_Enable(intDMA8, DMA_LINK_RX_Handler);
	//запуск работы канала dma_ch_num DMA
	HAL_DMA_WriteDC(dma_ch_num,  &link_dma_rx_tcb);

	//сброс флага готовности
	adc_dma_done = 0;


}


//функция перепаковки данных от АЦП из  сдвоенных 32 в 16 битные
static void repack_adc_data_short(unsigned int *data_in, int *data_out, unsigned int count)
{

	unsigned int temp;
	unsigned int s[2];
	while(count)
	{
		temp = *data_in++;

		//получение двух отсчетов от АЦП из одного слова
		s[0] = temp & 0xFFFF;
		s[1] = temp >> 16;

		//освобождение битов для знака
		s[0] >>= 2;
		s[1] >>= 2;

		//определение знака новых отсчетов
		s[0] |= (s[0] & 0x2000) ? 0xFFFFC000 : 0;
		s[1] |= (s[1] & 0x2000) ? 0xFFFFC000 : 0;


		*data_out++ = s[0];
		*data_out++ = s[1];

		count--;
	}
}
