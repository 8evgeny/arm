#ifndef __XPT2046_VC3_H_
#define __XPT2046_VC3_H_

#include "stdint.h"







#endif //__XPT2046_VC3_H_
