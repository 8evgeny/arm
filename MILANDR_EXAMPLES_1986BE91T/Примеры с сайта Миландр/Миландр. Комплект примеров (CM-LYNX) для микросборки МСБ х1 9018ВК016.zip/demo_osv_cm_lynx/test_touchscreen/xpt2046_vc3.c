

#include "board.h"
#include "xpt2046_vc3.h"


#define XPT_SWAP_X_WITH_Y	0

static uint32_t xpt_cmd_x;
static uint32_t xpt_cmd_y;



void touch_LowLevelInit(void *initParams)
{
	SPI_Init_type spi_ini_str;
	uint32_t spi_touch_pins;
	
	xpt_cmd_x = (1 << 7)	|	// S - start conversion
#if XPT_SWAP_X_WITH_Y == 1
				(0 << 6)	|	// A2
#else
				(1 << 6)	|	// A2
#endif
				(0 << 5)	|	// A1
				(1 << 4)	|	// A0
				//(1 << 3)	|	// mode, 12bit (0) or 8 bit (1)
				//(1 << 2)	|	// SER/DFR single-ended (1) / differential (0) reference
				(0 << 1)	|	// PD1
				(0 << 0)	|	// PD0
				0;
				
	xpt_cmd_y = (1 << 7)	|	// S - start conversion
#if XPT_SWAP_X_WITH_Y == 1
				(1 << 6)	|	// A2
#else
				(0 << 6)	|	// A2
#endif
				(0 << 5)	|	// A1
				(1 << 4)	|	// A0
				//(1 << 3)	|	// mode, 12bit (0) or 8 bit (1)
				//(1 << 2)	|	// SER/DFR single-ended (1) / differential (0) reference
				(0 << 1)	|	// PD1
				(0 << 0)	|	// PD0
				0;
				
	LX_GPIO_PA->DDR.CLR = (1 << 27);
	LX_GPIO_PA->ALT.CLR = (1 << 27);

	spi_touch_pins = (1<<4) |
				 	(1<<5) |
					(1<<6) |
					(1 << (7 + 0)); //cs0
	
	HAL_GPIO_Init (LX_GPIO_PA, spi_touch_pins, GPIO_PinMode_Alt);

	//инициализация spi для работы с тач
	spi_ini_str.CSNum = 0;
	spi_ini_str.WordSize = 12;
	spi_ini_str.CLK_Polarity = SPI_CLK_Polarity_High;
	spi_ini_str.CLK_Phase = SPI_CLK_Phase_Negedge;
	spi_ini_str.FirstBit = SPI_FirstBit_MSB;
	spi_ini_str.CLK_Prescaler = 1999;
	spi_ini_str.Mode = SPI_Mode_Master;
	spi_ini_str.CS_Hold = SPI_CS_Unhold;
	spi_ini_str.CS_Hold_Delay = 3;
	spi_ini_str.CS_Active = SPI_CS_Active_Low;
	spi_ini_str.LoopBack = SPI_LoopBack_Off;

	HAL_SPI_Init (LX_SPI0, &spi_ini_str);

}

uint32_t touch_IsTouched(void)
{
	return !(LX_GPIO_PA->PXD & (1 << 27));
}

static uint32_t touch_GetData(uint32_t request)
{
	uint32_t rx_data;
	uint16_t response_data_part_one;
    uint16_t response_data_part_two;
    uint16_t result;

    LX_SPI0->SPCR1.b.HOLDCS = 1;

    rx_data = request << 4;
    HAL_SPI_SendAndReceive (LX_SPI0, &rx_data, &response_data_part_one, 1);
    rx_data = 0x00;
    HAL_SPI_SendAndReceive (LX_SPI0, &rx_data, &response_data_part_two, 1);

    LX_SPI0->SPCR1.b.HOLDCS = 0;

    result = response_data_part_one << 12;
    result |= response_data_part_two;
    result >>= 3;

	result &= 0xFFF;    
    return result;
}

uint32_t touch_ReadRawX(void)
{
    return touch_GetData(xpt_cmd_x);
}

uint32_t touch_ReadRawY(void)
{
	return touch_GetData(xpt_cmd_y);
}

