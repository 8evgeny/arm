/*****************************************************************************
 * test_lcd.c
 *****************************************************************************/

#include <stdio.h>
#include "board.h"
#include "lcd_lib.h"
#include "touch.h"
#include "xpt2046_vc3.h"


uint32_t *vbuf = (uint32_t*)0x40000000; //адресс SDRAM для работы с LCD
__builtin_quad	qw_tcb; //TCB для работы LCD и DMA
char str[50];

//инициализация LCD контроллера
void LCD_init(void *vbuf)
{
	LCD_Conf_type hal_lcd_cfg;
		LCD_WindowConf_type window_cfg;


		hal_lcd_cfg.ulRgbMode 			= HAL_LCD_RGB565;
		hal_lcd_cfg.ulPixelClock		= 5000;
		hal_lcd_cfg.ulPwmDiv			= 12;		// 307Hz PWM @250MHz core
		hal_lcd_cfg.bPClkInverse		= 0;
		hal_lcd_cfg.bStopPclkWhenNoData = 1;
		hal_lcd_cfg.bSwapRgbToBgr 		= 0;
		hal_lcd_cfg.bDReadyActiveLevel	= 1;

		hal_lcd_cfg.bHSyncActiveLevel	= 0;
		hal_lcd_cfg.usHSyncPos 			= 1;
		hal_lcd_cfg.usHSyncLen 			= 5;
		hal_lcd_cfg.usHSize 			= 480;

		hal_lcd_cfg.bVSyncActiveLevel	= 0;
		hal_lcd_cfg.usVSyncPos 			= 1;
		hal_lcd_cfg.usVSyncLen 			= 2;

		hal_lcd_cfg.usHFrontBlank 		= 10;
		hal_lcd_cfg.usVSize 			= 272;
		hal_lcd_cfg.usHBackBlank 		= 40;

		hal_lcd_cfg.usVBackBlank 		= 10;
		hal_lcd_cfg.usVFrontBlank 		= 10;


		window_cfg.sHOffset = 20;
		window_cfg.sVOffset = 10;
		window_cfg.usHSize = LCD_XSIZE;
		window_cfg.usVSize = LCD_YSIZE;

		window_cfg.ulBackgndColor = LCD_WINDOW_BCKGRND_FROM_RGB(170, 100, 20);

		hal_lcd_cfg.pxWindow = 0;

		HAL_LCD_GpioInit();
		HAL_LCD_Setup(&hal_lcd_cfg);
		HAL_LCD_StartDma(LCD_DMA_CHANNEL, vbuf, LCD_XSIZE, LCD_YSIZE, hal_lcd_cfg.ulRgbMode, 0);

		//инициализация LCD
		HAL_LCD_Enable();
		HAL_LCD_PwmSetDuty(90);
}

void Fill_Black_LCD(void)
{
	LCD_SetFillColor(CL_BLACK);
	LCD_FillRectP(0, 0, LCD_XSIZE, LCD_YSIZE);
}

void Calibrate(void)
{
	touchCalibration_t calib;

	struct {
		uint32_t x0;
		uint32_t y0;
		uint32_t x1;
		uint32_t y1;
	} coord;

	coord.x0=30,
	coord.y0=30,
	coord.x1=400,
	coord.y1=200;


	LCD_SetFillColor(CL_BLUE);
	LCD_FillRectP(coord.x0-4, coord.y0-4, coord.x0+4, coord.y0+4);
	LCD_PrintString("Press on blue rectangle", 10, 80);
	while (!touch_GetXy(0,0));
	wait_msec(10);
	touch_GetXy(0,0);
	touch_SaveCalibrationPoint(0, coord.x0, coord.y0);
	do {
		wait_msec(100);
	} while (touch_GetXy(0,0));

	LCD_SetFillColor(CL_RED);
	LCD_FillRectP(coord.x1-4, coord.y1-4, coord.x1+4, coord.y1+4);
	LCD_PrintString("Press on red rectangle", 10, 80);
	while (!touch_GetXy(0,0));
	wait_msec(10);
	touch_GetXy(0,0);
	touch_SaveCalibrationPoint(1, coord.x1, coord.y1);
	do {
		wait_msec(100);
	} while (touch_GetXy(0,0));

	touch_UpdateCalibration();
	touch_ExportCalibration(&calib);

	LCD_SetPenColor(CL_WHITE);
	sprintf (str, "%f",calib.x_k);
	LCD_PrintString("x_k:",150,80);
	LCD_PrintString(str,250,80);

	sprintf (str, "%f",calib.x_offset);
	LCD_PrintString("x_offset",150,100);
	LCD_PrintString(str,250,100);

	sprintf (str, "%f",calib.y_k);
	LCD_PrintString("y_k",150,120);
	LCD_PrintString(str,250,120);

	sprintf (str, "%f",calib.y_offset);
	LCD_PrintString("y_offset",150,140);
	LCD_PrintString(str,250,140);

	wait_msec(2000);
}



int main( void )
{
	int32_t x,y;


	BRD_init();
	BRD_SDRAM_init();
	Init_LEDS_Port();

	//инициализация твч-контроллера
	touch_Init(0);
	touch_SetValidArea(0, LCD_XSIZE-1, 0, LCD_YSIZE-1);

	//запуск LCD
	LCD_init(vbuf);

	BRD_LED_setState(brdLed1);

	LCD_SetFont(&font_h12);
	LCD_SetImageOutputMode(IMAGE_PAINT_SET_PIXELS | IMAGE_PAINT_VOID_PIXELS);
	LCD_SetPenColor(CL_WHITE);

#if 0
	int32_t pressed;
	Fill_Black_LCD();
	while(1)
	{
		pressed = touch_IsTouched();
		x = touch_ReadRawX();
		y = touch_ReadRawY();

		if (pressed)
			LCD_PrintString("Pressed ", 10, 80);
		else
			LCD_PrintString("Released", 10, 80);
		sprintf(str, "X: %05d", x);
		LCD_PrintString(str, 10, 100);
		sprintf(str, "Y: %05d", y);
		LCD_PrintString(str, 10, 120);

		wait_msec(20);
	}
#endif


    //запуск колибровки
	Fill_Black_LCD();
	Calibrate();
	Fill_Black_LCD();

	LCD_PrintString("Coordinate X:", 10, 100);
	LCD_PrintString("Coordinate Y:", 10, 120);


	while(1)
	{
		if (touch_GetXy(&x,&y))
		{
			BRD_LED_setState(brdLed2);

			LCD_SetFillColor(CL_BLACK);
			LCD_FillRectP(100, 100, 150, 150);

			LCD_SetPenColor(CL_WHITE);
			sprintf (str, "%d",x);
			LCD_PrintString(str,100,100);
			sprintf (str, "%d",y);
			LCD_PrintString(str,100,120);
		}
		else
		{
			BRD_LED_setState(brdLed2);
		}
		wait_msec(20);
	}
}

