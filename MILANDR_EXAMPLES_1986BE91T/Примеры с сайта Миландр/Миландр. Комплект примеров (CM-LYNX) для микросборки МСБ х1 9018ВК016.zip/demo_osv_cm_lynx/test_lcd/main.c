/*****************************************************************************
 * test_lcd.c
 *****************************************************************************/

#include <stdio.h>
#include "board.h"
#include "lcd_lib.h"


uint32_t *vbuf = (uint32_t*)0x40000000; //адресс SDRAM для работы с LCD
__builtin_quad	qw_tcb; //TCB для работы LCD и DMA

//инициализация LCD контроллера
void LCD_init(void *vbuf)
{
	LCD_Conf_type hal_lcd_cfg;
	LCD_WindowConf_type window_cfg;


	hal_lcd_cfg.ulRgbMode 			= HAL_LCD_RGB565;
	hal_lcd_cfg.ulPixelClock		= 5000;
	hal_lcd_cfg.ulPwmDiv			= 12;		// 307Hz PWM @250MHz core
	hal_lcd_cfg.bPClkInverse		= 0;
	hal_lcd_cfg.bStopPclkWhenNoData = 1;
	hal_lcd_cfg.bSwapRgbToBgr 		= 0;
	hal_lcd_cfg.bDReadyActiveLevel	= 1;

	hal_lcd_cfg.bHSyncActiveLevel	= 0;
	hal_lcd_cfg.usHSyncPos 			= 1;
	hal_lcd_cfg.usHSyncLen 			= 5;
	hal_lcd_cfg.usHSize 			= 480;

	hal_lcd_cfg.bVSyncActiveLevel	= 0;
	hal_lcd_cfg.usVSyncPos 			= 1;
	hal_lcd_cfg.usVSyncLen 			= 2;

	hal_lcd_cfg.usHFrontBlank 		= 10;
	hal_lcd_cfg.usVSize 			= 272;
	hal_lcd_cfg.usHBackBlank 		= 40;

	hal_lcd_cfg.usVBackBlank 		= 10;
	hal_lcd_cfg.usVFrontBlank 		= 10;


	window_cfg.sHOffset = 20;
	window_cfg.sVOffset = 10;
	window_cfg.usHSize = LCD_XSIZE;
	window_cfg.usVSize = LCD_YSIZE;

	window_cfg.ulBackgndColor = LCD_WINDOW_BCKGRND_FROM_RGB(170, 100, 20);

	hal_lcd_cfg.pxWindow = 0;

	HAL_LCD_GpioInit();
	HAL_LCD_Setup(&hal_lcd_cfg);
	HAL_LCD_StartDma(LCD_DMA_CHANNEL, vbuf, LCD_XSIZE, LCD_YSIZE, hal_lcd_cfg.ulRgbMode, 0);

	// Enable LCD
	HAL_LCD_Enable();
	HAL_LCD_PwmSetDuty(90);
}




int main( void )
{
	unsigned int i,j;
	unsigned int x0,y0,r;
	color_t cl;
	int seed;
	char str[20];

	BRD_init();
	BRD_SDRAM_init();
	Init_LEDS_Port();


	LCD_SetFillColor(CL_BLACK);
	LCD_FillRectP(0, 0, LCD_XSIZE - 1, LCD_YSIZE - 1);

	LCD_SetFillColor(CL_YELLOW);
	LCD_FillRectP(0, 0, 9, 9);

	LCD_SetFillColor(CL_RED);
	LCD_FillRectP(LCD_XSIZE - 10, 0, LCD_XSIZE - 1, 9);

	LCD_SetFillColor(CL_GREEN);
	LCD_FillRectP(LCD_XSIZE - 10, LCD_YSIZE - 10, LCD_XSIZE - 1, LCD_YSIZE - 1);

	LCD_SetFillColor(CL_BLUE);
	LCD_FillRectP(0, LCD_YSIZE - 10, 9, LCD_YSIZE - 1);

	LCD_SetFont(&font_h12);
	LCD_SetImageOutputMode(IMAGE_PAINT_SET_PIXELS);
	LCD_SetPenColor(CL_WHITE);
	LCD_PrintString("Osvedomlennost' board LCD test project", 90, 30);


	LCD_init(vbuf);


	BRD_LED_setState(brdLed1);

	x0 = LCD_XSIZE / 2;
	y0 = 170;
	r = 80;
	seed = CL_RED;

	while(1)
	{
		seed = _LFSR32_fast(seed);
		cl = (color_t)seed;
		LCD_SetPenColor(cl);
		LCD_SetFillColor(cl);

		LCD_DrawFilledCircle(x0, y0, 5);
		for (i=6; i<r; i+=1)
		{
			LCD_DrawFilledCircle(x0, y0, i);
			wait_msec(2);
		}
		sprintf(str, "Buttons: 0x%02X ", BRD_GetButtons());
		LCD_SetImageOutputMode(IMAGE_PAINT_SET_PIXELS | IMAGE_PAINT_VOID_PIXELS);
		LCD_SetPenColor(CL_WHITE);
		LCD_SetAltPenColor(CL_BLACK);
		LCD_PrintString(str, 90, 50);
	}
}

