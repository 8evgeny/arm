/*
������ ��������� ������ aic23
*/
#include "tlv320aic23.h"
#include "tlv320aic23_private.h"
#include "config.h"


//#define UINT_MAX  4.2950e+009
#define UINT_MAX         4294967295U
//#define UINT16_MAX         65535U

//---------------------AIC23
static uint16_t tlv320aic23_reg[16];
static uint32_t mclk;

/*
250  * Common Crystals used
251  * 11.2896 Mhz /128 = *88.2k  /192 = 58.8k
252  * 12.0000 Mhz /125 = *96k    /136 = 88.235K
253  * 12.2880 Mhz /128 = *96k    /192 = 64k
254  * 16.9344 Mhz /128 = 132.3k /192 = *88.2k
255  * 18.4320 Mhz /128 = 144k   /192 = *96k
*/
 
/*
259  * Normal BOSR 0-256/2 = 128, 1-384/2 = 192
260  * USB BOSR 0-250/2 = 125, 1-272/2 = 136
261 */

static int32_t bosr_usb_divisor_table[4];
static uint16_t sr_valid_mask[4];

static unsigned char sr_adc_mult_table[16];
static unsigned char sr_dac_mult_table[16];



void init_tlv320aic23() 
{
	tlv320aic23_config_t ac_cfg;
		//-------- Setup audiocodec --------//
	// Samples are 16-bit, signed

	ac_cfg.mclk_hz = 12000000;
	ac_cfg.sample_rate = 16000;
	ac_cfg.digital_if_mode = DigitalIfDSP;
	ac_cfg.digital_if_settings.dsp_mode.bits_per_sample = AcSampleWidth_16;
	ac_cfg.digital_if_settings.dsp_mode.left_right_swap = 0;
	ac_cfg.digital_if_settings.dsp_mode.master = 1;
	ac_cfg.digital_if_settings.dsp_mode.msb_on_2nd_bclk = 1;
	ac_cfg.input_settings.source = AcInputMic;
	ac_cfg.input_settings.mic_boost = 1;
	ac_cfg.input_settings.mic_mute = 0;
	ac_cfg.input_settings.line_mute = 1;
	ac_cfg.output_settings.gain_upd_on_zero_cross = 0;
	ac_cfg.output_settings.gain = 121;

	if (tlv320aic23_probe(&ac_cfg) != 0)
	{
		while (1) {}
	}
	
}

static void tlv320aic23_wait(int count)
{
	volatile int i;
	for(i = 0; 10000 > i; i++);
}


//  read tlv320aic23 register cache
static uint16_t tlv320aic23_read_reg_cache(uint16_t reg)
{
	if (reg >= sizeof(tlv320aic23_reg))
		return UINT16_MAX; //-1;
	return tlv320aic23_reg[reg];
}


// write tlv320aic23 register cache
static void tlv320aic23_write_reg_cache(uint16_t reg, uint16_t value)
{

	if (reg >= sizeof(tlv320aic23_reg))
		return;
	tlv320aic23_reg[reg] = value;
}


static uint16_t tlv320aic23_write(uint16_t reg, uint16_t value)
{
	unsigned int data_tx;
	if (reg > 9 && reg != 15)
	{
		return UINT16_MAX; //-1;
	}
	tlv320aic23_write_reg_cache(reg, value);
	data_tx = (reg << 9) | (value & 0x1FF);
	tlv320aic23_spi_send_receive(data_tx);

	tlv320aic23_wait(10000);
	return 0;
}


static uint32_t tlv320aic23_get_score(int32_t adc, int32_t adc_l, int32_t adc_h, int32_t need_adc,int32_t dac, int32_t dac_l, int32_t dac_h, int32_t need_dac)
{
	int32_t diff_adc;
	int32_t diff_dac;

	if ((adc >= adc_l) && (adc <= adc_h) && (dac >= dac_l) && (dac <= dac_h)) 
	{
		diff_adc = need_adc - adc;
		diff_dac = need_dac - dac;
		//return abs(diff_adc) + abs(diff_dac);
		return ((diff_adc < 0) ? -diff_adc : diff_adc) + ((diff_dac < 0) ? -diff_dac : diff_dac);
	}
	return UINT_MAX;
}


// AIC23 register cache
static void tlv320aic23_init(void)
{
	//I2C1_Master_Init(); /*Init I2C interface*/
//init cash
	tlv320aic23_reg[TLV320AIC23_LINVOL]	= 0x0097; 	
	tlv320aic23_reg[TLV320AIC23_RINVOL]	= 0x0097;
	tlv320aic23_reg[TLV320AIC23_LCHNVOL]= 0x00F9;
	tlv320aic23_reg[TLV320AIC23_RCHNVOL]= 0x00F9;
	tlv320aic23_reg[TLV320AIC23_ANLG]	= 0x001A;
	tlv320aic23_reg[TLV320AIC23_DIGT]	= 0x0004;
	tlv320aic23_reg[TLV320AIC23_PWR]	= 0x0007;
	tlv320aic23_reg[TLV320AIC23_DIGT_FMT]=0x0001;
	tlv320aic23_reg[TLV320AIC23_SRATE]	= 0x0020;
	tlv320aic23_reg[TLV320AIC23_ACTIVE]	= 0x0000;
	tlv320aic23_reg[TLV320AIC23_RESET]	= 0x0000;	
	tlv320aic23_reg[11]					= 0x0000;
	tlv320aic23_reg[12]					= 0x0000;
	tlv320aic23_reg[13]					= 0x0000;
	tlv320aic23_reg[14]					= 0x0000;
	tlv320aic23_reg[15]					= 0x0000;
	
	bosr_usb_divisor_table[0]=93750; 
	bosr_usb_divisor_table[1]=96000; 
	bosr_usb_divisor_table[2]=62500; 
	bosr_usb_divisor_table[3]=88235;

	sr_valid_mask[0] = LOWER_GROUP|UPPER_GROUP;
	sr_valid_mask[1] = LOWER_GROUP;
	sr_valid_mask[2] = LOWER_GROUP|UPPER_GROUP;
	sr_valid_mask[3] = UPPER_GROUP;
 
	sr_adc_mult_table[0]=66;
	sr_adc_mult_table[1]=66;
	sr_adc_mult_table[2]=11;
	sr_adc_mult_table[3]=11;
	sr_adc_mult_table[4]=0;
	sr_adc_mult_table[5]=0;
	sr_adc_mult_table[6]=44;
	sr_adc_mult_table[7]=132;
	sr_adc_mult_table[8]=66;
	sr_adc_mult_table[9]=66;
	sr_adc_mult_table[10]=12;
	sr_adc_mult_table[11]=12;
	sr_adc_mult_table[12]=0;
	sr_adc_mult_table[13]=0;
	sr_adc_mult_table[14]=0;
	sr_adc_mult_table[15]=132;
	
	sr_dac_mult_table[0]=66;
	sr_dac_mult_table[1]=11;
	sr_dac_mult_table[2]=66;
	sr_dac_mult_table[3]=11;
	sr_dac_mult_table[4]=0;
	sr_dac_mult_table[5]=0;
	sr_dac_mult_table[6]=44;
	sr_dac_mult_table[7]=132;
	sr_dac_mult_table[8]=66;
	sr_dac_mult_table[9]=12;
	sr_dac_mult_table[10]=66;
	sr_dac_mult_table[11]=12;
	sr_dac_mult_table[12]=0;
	sr_dac_mult_table[13]=0;
	sr_dac_mult_table[14]=0;
	sr_dac_mult_table[15]=132;
}


static uint16_t tlv320aic23_set_bias_level(uint16_t level)
{
	uint16_t reg;
	reg =tlv320aic23_read_reg_cache(TLV320AIC23_PWR) & 0xff7f;

    switch (level) 
    {
		case SND_SOC_BIAS_ON:
			// vref/mid, osc on, dac unmute
			reg &= ~(TLV320AIC23_DEVICE_PWR_OFF | TLV320AIC23_OSC_OFF | TLV320AIC23_DAC_OFF);
			reg &= ~(TLV320AIC23_ADC_OFF | TLV320AIC23_MIC_OFF | TLV320AIC23_OUT_OFF);
			tlv320aic23_write(TLV320AIC23_PWR, reg);
			break;
		case SND_SOC_BIAS_PREPARE:
			break;
		case SND_SOC_BIAS_STANDBY:
			// everything off except vref/vmid,
			tlv320aic23_write(TLV320AIC23_PWR, reg | TLV320AIC23_CLK_OFF);
			break;
		case SND_SOC_BIAS_OFF:
			// everything off, dac mute, inactive 
			tlv320aic23_write(TLV320AIC23_ACTIVE, 0x0);
			tlv320aic23_write(TLV320AIC23_PWR, 0xffff);
			break;
	}

	return 0;
}


static int32_t tlv320aic23_find_rate(uint16_t mclk, uint32_t need_adc, uint32_t need_dac)
{
	int32_t i, j;
	int32_t best_i;
	int32_t best_j;
	int32_t best_div = 0;
	uint32_t best_score;
	int32_t adc_l, adc_h, dac_l, dac_h;
	int32_t base;
	int32_t mask;
	int32_t adc;
	int32_t dac;
	int32_t score;

	best_i = -1;
	best_j = -1;
 	best_score = UINT_MAX;
 	adc=0x0000;
 	dac=0x0000;
 	
	need_adc *= SR_MULT;
	need_dac *= SR_MULT;
//	rates given are +/- 1/32
	adc_l = need_adc - (need_adc >> 5);
	adc_h = need_adc + (need_adc >> 5);
	dac_l = need_dac - (need_dac >> 5);
	dac_h = need_dac + (need_dac >> 5);
	for (i = 0; i < sizeof(bosr_usb_divisor_table); i++) 
	{
	
		base = bosr_usb_divisor_table[i];
		mask = sr_valid_mask[i];
		for (j = 0; j < sizeof(sr_adc_mult_table); j++, mask >>= 1) 
		{		
			if ((mask & 1) == 0)
				continue;
			adc = base * sr_adc_mult_table[j];
			dac = base * sr_dac_mult_table[j];			
    		score =tlv320aic23_get_score(adc, adc_l, adc_h, need_adc,dac, dac_l, dac_h, need_dac);
			if (best_score > score) 
			{
				best_score = score;
				best_i = i;
				best_j = j;
				best_div = 0;
			}
			score =tlv320aic23_get_score((adc >> 1), adc_l, adc_h, need_adc,(dac >> 1), dac_l, dac_h, need_dac);
			// prefer to have a /2 
			if ((score != UINT_MAX) && (best_score >= score)) 
			{
				best_score = score;
				best_i = i;
				best_j = j;
				best_div = 1;
			}
		}
	}
	return (best_j << 2) | best_i | (best_div << TLV320AIC23_CLKIN_SHIFT);
}


static uint16_t tlv320aic23_set_sample_rate_control(uint32_t mclk,uint32_t sample_rate_adc, uint32_t sample_rate_dac)
{
// Search for the right sample rate
	int32_t data;

	data = tlv320aic23_find_rate(mclk, sample_rate_adc, sample_rate_dac);
	if (data < 0) 
		return UINT16_MAX; //-1;
	tlv320aic23_write(TLV320AIC23_SRATE, data );
	return 0;
	
}


uint16_t tlv320aic23_probe(tlv320aic23_config_t *cfg)
{
	uint16_t reg, temp16u;
    volatile int i;
    uint16_t rate_ok = 0;

    mclk = cfg->mclk_hz;

    // Initialize
    tlv320aic23_init();

    // Deactivate digital interface
    tlv320aic23_write(TLV320AIC23_ACTIVE, 0x0);

    // Reset codec
	tlv320aic23_write(TLV320AIC23_RESET, 0);

	// Power on device
	tlv320aic23_set_bias_level(SND_SOC_BIAS_ON);

	// Digital path setup
	tlv320aic23_write(TLV320AIC23_DIGT, TLV320AIC23_ADCHP_ON);

	// Analog path setup
	temp16u = TLV320AIC23_DAC_SELECTED |
			(cfg->input_settings.source << 2) |
			(cfg->input_settings.mic_mute << 1) |
			(cfg->input_settings.mic_boost << 0);
	// TODO: add sidetone and bypass control
	tlv320aic23_write(TLV320AIC23_ANLG, temp16u);

    // Digital interface format
    if (cfg->digital_if_mode == DigitalIfDSP)
	{
		temp16u = (cfg->digital_if_settings.dsp_mode.master << 6) |
				(cfg->digital_if_settings.dsp_mode.left_right_swap << 5) |
				(cfg->digital_if_settings.dsp_mode.msb_on_2nd_bclk << 4) |
				(cfg->digital_if_settings.dsp_mode.bits_per_sample << 2) |
				TLV320AIC23_FOR_DSP;
	}
	else if (cfg->digital_if_mode == DigitalIfI2S)
	{
		temp16u = (cfg->digital_if_settings.i2s_mode.master << 6) |
				(cfg->digital_if_settings.i2s_mode.left_right_swap << 5) |
				(cfg->digital_if_settings.i2s_mode.right_ch_on_lrcin_low << 4) |
				(cfg->digital_if_settings.i2s_mode.bits_per_sample << 2) |
				(cfg->digital_if_settings.i2s_mode.format << 0);
	}
	else return UINT16_MAX;
	tlv320aic23_write(TLV320AIC23_DIGT_FMT, temp16u);

	// Input setup
	temp16u = (cfg->input_settings.line_mute << 7) |
			((cfg->input_settings.line_gain & 0x1F) << 0);
	tlv320aic23_write(TLV320AIC23_LINVOL, temp16u);
	tlv320aic23_write(TLV320AIC23_RINVOL, temp16u);

	// Output setup
	temp16u = (cfg->output_settings.gain_upd_on_zero_cross << 7) |
				((cfg->output_settings.gain & 0x7F) << 0);
	tlv320aic23_write(TLV320AIC23_LCHNVOL, temp16u);
	tlv320aic23_write(TLV320AIC23_RCHNVOL, temp16u);

	// Sample rate playback
	rate_ok = tlv320aic23_set_sample_rate_control(mclk, cfg->sample_rate, cfg->sample_rate);

	// Activate digital interface
	tlv320aic23_write(TLV320AIC23_ACTIVE, 0x1);
	return rate_ok;		// 0 = OK
}


// 48 (min) to 127 (max) - Default (0db) is 121
void tlv320aic23_set_volume(uint8_t lch_gain, uint8_t rch_gain)
{
	uint16_t temp16u;

	temp16u = tlv320aic23_read_reg_cache(TLV320AIC23_LCHNVOL);
	temp16u &= ~0x7F;
	temp16u |= (lch_gain & 0x7F);
	tlv320aic23_write(TLV320AIC23_LCHNVOL, temp16u);

	temp16u = tlv320aic23_read_reg_cache(TLV320AIC23_RCHNVOL);
	temp16u &= ~0x7F;
	temp16u |= (rch_gain & 0x7F);
	tlv320aic23_write(TLV320AIC23_RCHNVOL, temp16u);
}



uint16_t tlv320aic23_set_srate(uint16_t sample_rate)
{
	uint16_t rate_ok;
	rate_ok = tlv320aic23_set_sample_rate_control(mclk, sample_rate, sample_rate);
    return rate_ok;		// 0 = OK
}





