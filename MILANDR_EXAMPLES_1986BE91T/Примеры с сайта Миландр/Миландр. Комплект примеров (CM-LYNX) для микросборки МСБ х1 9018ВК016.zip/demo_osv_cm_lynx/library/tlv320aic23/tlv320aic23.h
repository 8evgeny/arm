#ifndef _TLV320AIC23_H
#define _TLV320AIC23_H



#include "stdint.h"


enum AcDigitalIfModes {
	DigitalIfI2S,
	DigitalIfDSP
};

enum AcDigitalIfFormats {
	FmtRightJustified,
	FmtLeftJustified,
	FmtI2S
};

enum AcDigitalIfSampleWidths {
	AcSampleWidth_16,
	AcSampleWidth_20,
	AcSampleWidth_24,
	AcSampleWidth_32
};

enum AcAdcInputSources {
	AcInputLine,
	AcInputMic
};

typedef struct {
	uint32_t mclk_hz;							// 12000000, 18432000, etc
	uint32_t sample_rate;						// 8000, 22050, 24000, etc
	uint8_t digital_if_mode;					// One of AcDigitalIfModes
	union {
		struct {
			uint32_t master :1;					// If 1, TLV320 is master
			uint32_t left_right_swap :1;		// If 1, channels are swapped
			uint32_t msb_on_2nd_bclk :1;		// if 1, MSB is avaliable on 2nd BCLK rising edge after LRCIN rising edge
			uint8_t bits_per_sample :2;			// Input bit length, one of AcDigitalIfSampleWidths
												// Defines sample width for a single channel
		} dsp_mode;
		struct {
			uint32_t master :1;					// If 1, TLV320 is master
			uint32_t left_right_swap :1;		// If 1, channels are swapped
			uint32_t right_ch_on_lrcin_low :1;	// DAC left/right phase
			uint8_t bits_per_sample :2;			// Input bit length, one of AcDigitalIfSampleWidths
												// Defines sample width for a single channel
			uint8_t format : 2;					// One of AcDigitalIfFormats
		} i2s_mode;
	} digital_if_settings;
	struct {
		uint8_t source :1;						// One of AcAdcInputSources
		uint32_t line_mute :1;
		uint8_t line_gain;						// 10111 = 0 dB default
												// 11111 = +12 dB down to 00000 = �34.5 dB in 1.5-dB steps
		uint32_t mic_mute :1;
		uint32_t mic_boost :1;
	} input_settings;
	struct {
		uint32_t gain_upd_on_zero_cross :1;
		uint8_t gain;							// 1111001 = 0 dB default
												// 1111111 = +6 dB, 79 steps between +6 dB and -73 dB (mute), 0110000 = -73 dB (mute)
	} output_settings;
} tlv320aic23_config_t;



#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus
	void init_tlv320aic23(void);
	uint16_t tlv320aic23_probe(tlv320aic23_config_t *cfg);
	void tlv320aic23_set_volume(uint8_t lch_gain, uint8_t rch_gain);
	uint16_t tlv320aic23_set_srate(uint16_t sample_rate);

	extern uint32_t tlv320aic23_spi_send_receive(uint32_t  data_tx);

#ifdef __cplusplus
}
#endif // __cplusplus


#endif /* _TLV320AIC23_H */

