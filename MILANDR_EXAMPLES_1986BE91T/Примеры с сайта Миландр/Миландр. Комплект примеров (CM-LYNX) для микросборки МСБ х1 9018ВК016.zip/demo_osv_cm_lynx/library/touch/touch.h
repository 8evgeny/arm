#ifndef __TOUCH_H_
#define __TOUCH_H_

#include "stdint.h"


typedef struct {
	float x_k;
	float x_offset;
	float y_k;
	float y_offset;
} touchCalibration_t;



//----------- Prototypes -----------//

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

	void touch_Init(void *initParams);
	void touch_SetValidArea(int32_t x_min, int32_t x_max, int32_t y_min, int32_t y_max);
	uint32_t touch_GetXy(int32_t *x, int32_t *y);
	void touch_SaveCalibrationPoint(uint32_t numOfPoint, int32_t x, int32_t y);
	void touch_UpdateCalibration(void);
	void touch_ExportCalibration(touchCalibration_t *c);
	void touch_ImportCalibration(touchCalibration_t *c);

	// Must be implemented in according to controller protocol
	extern void touch_LowLevelInit(void *initParams);
	extern uint32_t touch_IsTouched(void);
	extern uint32_t touch_ReadRawX(void);
	extern uint32_t touch_ReadRawY(void);


#ifdef __cplusplus
}
#endif // __cplusplus



#endif //__TOUCH_H_
