#include "touch.h"


static struct {
	float x_iir;
	float y_iir;
	int32_t recent_x;
	int32_t recent_y;
	struct {
		int32_t x_min;
		int32_t x_max;
		int32_t y_min;
		int32_t y_max;
	} bound;	
	struct {
		float raw_x;
		float raw_y;
		float x;
		float y;
	} calibrationPoints[2];
	touchCalibration_t calibration;
	uint32_t touchStateCnt;
	uint32_t isTouched;
} touchState;



void touch_Init(void *initParams)
{
	touch_LowLevelInit(initParams);
	touchState.bound.x_min = 0;
	touchState.bound.x_max = 4096;
	touchState.bound.y_min = 0;
	touchState.bound.y_max = 4096;
	touchState.calibration.x_k = 1;
	touchState.calibration.x_offset = 0;
	touchState.calibration.y_k = 1;
	touchState.calibration.y_offset = 0;
}


void touch_SetValidArea(int32_t x_min, int32_t x_max, int32_t y_min, int32_t y_max)
{
	touchState.bound.x_min = x_min;
	touchState.bound.x_max = x_max;
	touchState.bound.y_min = y_min;
	touchState.bound.y_max = y_max;
}



// Returns 1 if toush is pressed, 0 otherwise
// Coordinates are returned by modifying arguments
uint32_t touch_GetXy(int32_t *x, int32_t *y)
{
	uint32_t raw_x, raw_y;
	uint32_t touched1, touched2;

	touched1 = touch_IsTouched();
	if (touched1)
	{
		raw_x = touch_ReadRawX();
		raw_y = touch_ReadRawY();
		touched2 = touch_IsTouched();
	}
	touched2 &= touched1;
	if (touched2)
	{
		// Process touch filter
		if (touchState.touchStateCnt < 10)
			touchState.touchStateCnt++;
			
		// Process filters
		touchState.x_iir = (touchState.touchStateCnt > 5) ? 0.8 * touchState.x_iir + 0.2 * (float)raw_x : raw_x;
		touchState.y_iir = (touchState.touchStateCnt > 5) ? 0.8 * touchState.y_iir + 0.2 * (float)raw_y : raw_y;
		
		touchState.recent_x = (int32_t)((float)touchState.x_iir * touchState.calibration.x_k + touchState.calibration.x_offset);
		touchState.recent_y = (int32_t)((float)touchState.y_iir * touchState.calibration.y_k + touchState.calibration.y_offset);
		
		// Bound
		if (touchState.recent_x < touchState.bound.x_min)	touchState.recent_x = touchState.bound.x_min;
		else if (touchState.recent_x > touchState.bound.x_max)	touchState.recent_x = touchState.bound.x_max; 
		if (touchState.recent_y < touchState.bound.y_min)	touchState.recent_y = touchState.bound.y_min;
		else if (touchState.recent_y > touchState.bound.y_max)	touchState.recent_y = touchState.bound.y_max; 
	}
	else
	{
		touchState.touchStateCnt = 0;
	}

	if (x)	*x = touchState.recent_x;
	if (y)	*y = touchState.recent_y;
	
	return touchState.touchStateCnt >= 10;
}


void touch_SaveCalibrationPoint(uint32_t numOfPoint, int32_t x, int32_t y)
{
	if (numOfPoint >= 2) return;
	touchState.calibrationPoints[numOfPoint].raw_x = (float)touchState.x_iir;
	touchState.calibrationPoints[numOfPoint].raw_y = (float)touchState.y_iir;
	touchState.calibrationPoints[numOfPoint].x = (float)x;
	touchState.calibrationPoints[numOfPoint].y = (float)y;
}


void touch_UpdateCalibration(void)
{
	touchState.calibration.x_k = (touchState.calibrationPoints[0].x - touchState.calibrationPoints[1].x) /
							(touchState.calibrationPoints[0].raw_x - touchState.calibrationPoints[1].raw_x);
	touchState.calibration.x_offset = touchState.calibrationPoints[0].x - touchState.calibrationPoints[0].raw_x * touchState.calibration.x_k;
	touchState.calibration.y_k = (touchState.calibrationPoints[0].y - touchState.calibrationPoints[1].y) /
							(touchState.calibrationPoints[0].raw_y - touchState.calibrationPoints[1].raw_y);
	touchState.calibration.y_offset = touchState.calibrationPoints[0].y - touchState.calibrationPoints[0].raw_y * touchState.calibration.y_k;
}


void touch_ExportCalibration(touchCalibration_t *c)
{
	*c = touchState.calibration;
}

void touch_ImportCalibration(touchCalibration_t *c)
{
	touchState.calibration = *c;
}


