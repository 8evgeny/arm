

#include "signal_utils.h"
#include <builtins.h>


// Bit field manipulation
#define FEXT_POS(x)	(x << 8)
#define FEXT_LEN(x)	(x)


//-----------------------------------------------------------------//
// Repack raw data from 12-bit DDR ADC
//
// Count is 32-bit words (2x samples)
// Output buffer size must be count * 2
//-----------------------------------------------------------------//
void repack_adc_data_12bit(uint32_t *data_in, uint32_t *data_out, uint32_t count)
{
	uint32_t temp;
	uint32_t s[4];
	uint32_t bit_pos;
	uint32_t shift_unused = 2;
	while(count)
	{
		temp = *data_in++;
		
		
		// One word contains two samples
		s[0] = (temp & 0xFF) >> shift_unused;	// even
		temp >>= 8;
		s[1] = (temp & 0xFF) >> shift_unused;	// odd
		temp >>= 8;
		s[2] = (temp & 0xFF) >> shift_unused;	// even
		temp >>= 8;
		s[3] = (temp & 0xFF) >> shift_unused;	// odd
		
		// Decode 1
		temp = 0;
		bit_pos = 0;
		while(s[0] || s[1])
		{
			temp |= (s[0] & 0x01) << bit_pos++;
			temp |= (s[1] & 0x01) << bit_pos++;
			s[1] >>= 1;
			s[0] >>= 1;
		}
		*data_out++ = temp;
		
		// Decode 2
		temp = 0;
		bit_pos = 0;
		while(s[2] || s[3])
		{
			temp |= (s[2] & 0x01) << bit_pos++;
			temp |= (s[3] & 0x01) << bit_pos++;
			s[3] >>= 1;
			s[2] >>= 1;
		}
		*data_out++ = temp;
		
		count--;	
	}	
}

//-----------------------------------------------------------------//
// Split 16-bit samples, packed in 32-bit words, into separate words
//
// input_buffer_size is number of 32-bit words (2x samples)
// Output buffer size must be input_buffer_size * 2
//-----------------------------------------------------------------//
void unpack_data_32_to_16(uint32_t *data_in, uint32_t *data_out, uint32_t input_buffer_size, uint32_t sign_extend)
{
	uint32_t temp;
	uint32_t s[2];
	while(input_buffer_size)
	{
		temp = *data_in++;
		s[0] = temp & 0xFFFF;
		s[1] = temp >> 16;
		
		// Sign-extend
		if (sign_extend)
		{
			s[0] |= (s[0] & 0x8000) ? 0xFFFF0000 : 0;
			s[1] |= (s[1] & 0x8000) ? 0xFFFF0000 : 0;
		}
				
		*data_out++ = s[0];
		*data_out++ = s[1];
		
		input_buffer_size--;
	}
}



//-----------------------------------------------------------------//
// Split 16-bit samples, packed in 32-bit words, into separate words
//	in two different buffers
//
// input_buffer_size is number of 32-bit words (2x samples)
// Output buffers size must be input_buffer_size
//-----------------------------------------------------------------//
void unpack_data_32_to_16_two_buf(uint32_t *data_in, uint32_t *datal_out, uint32_t *datah_out, uint32_t input_buffer_size, uint32_t sign_extend)
{
	uint32_t temp;
	uint32_t s[2];
	while(input_buffer_size)
	{
		temp = *data_in++;
		s[0] = temp & 0xFFFF;
		s[1] = temp >> 16;
		
		// Sign-extend
		if (sign_extend)
		{
			s[0] |= (s[0] & 0x8000) ? 0xFFFF0000 : 0;
			s[1] |= (s[1] & 0x8000) ? 0xFFFF0000 : 0;
		}
				
		*datal_out++ = s[0];
		*datah_out++ = s[1];
		
		input_buffer_size--;
	}
}


//-----------------------------------------------------------------//
//	Unpack bytes from 32-bit words
//
//
//
//-----------------------------------------------------------------//
void unpack_u32_to_u8(uint32_t *src, uint8_t *dst, uint32_t src_byte_offset, uint32_t byte_count)
{
	uint32_t word_addr = src_byte_offset >> 2;
	uint32_t pos = (src_byte_offset & 0x3) * 8;
	uint32_t word = src[word_addr];
	uint8_t temp8u;
	while (byte_count)
	{
		temp8u = (uint8_t)(word >> pos);
		*dst++ = temp8u;
		byte_count--;
		if (pos == 24)
		{
			word_addr++;
			pos = 0;
			word = src[word_addr];	
		}
		else
		{
			pos += 8;	
		}
	}
}


//-----------------------------------------------------------------//
//	Pack bytes to 32-bit words
//
//
//
//-----------------------------------------------------------------//
void pack_u8_to_u32(uint8_t *src, uint32_t *dest, uint32_t dst_byte_offset, uint32_t byte_count)
{
	uint32_t word_addr = dst_byte_offset >> 2;
	uint32_t pos = (dst_byte_offset & 0x3) * 8;
	uint32_t word = dest[word_addr];
	uint8_t temp8u;
	while (byte_count)
	{
		temp8u = *src++;
		word &= ~(0xFF << pos);
		word |= temp8u << pos;
		if (pos == 24)
		{
			dest[word_addr] = word;
			word_addr++;
			pos = 0;
			word = dest[word_addr];
		}
		else
		{
			pos += 8;	
		}
		byte_count--;
	}
	if (pos != 0)
		dest[word_addr] = word;
}



//-----------------------------------------------------------------//
//	Get bit from a uint32_t and put it into another uint32_t
//
//
//
//-----------------------------------------------------------------//
void depBit(uint32_t *src, uint32_t *dst, uint32_t srcBitNum, uint32_t dstBitNum, uint32_t count)
{
	uint32_t bit;
	while(count--)
	{
		bit = __builtin_fext( (int)*src, FEXT_POS(srcBitNum) | FEXT_LEN(1) );
		*dst = __builtin_fdep( (int)*dst, bit, FEXT_POS(dstBitNum) | FEXT_LEN(1) );
		src++;
		dst++;
	}
	
}



