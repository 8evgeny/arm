#ifndef __ARG_PARSER_H_
#define __ARG_PARSER_H_

#include "stdint.h"


enum ArgParserResultValues {
	apOk = 0,
	apError	= -1
};

typedef struct {
	char *key;
	uint32_t val;
} key_value_t;


#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

uint8_t splitString(char *sourceString, uint16_t sourceLength, char **words, uint8_t maxWordCount);
int16_t getIndexOfKey(char **strArray, uint8_t arraySize, const char *key);
int8_t getStringForKey(char **strArray, uint8_t arraySize, const char *key, char**result);
int8_t getValueUI32ForKey(char **strArray, uint8_t arraySize, const char *key, uint32_t *result);
int8_t decodeKey(char *key, key_value_t *table, uint32_t table_size, uint32_t *val);

#ifdef __cplusplus
}
#endif // __cplusplus




#endif //__ARG_PARSER_H_	

