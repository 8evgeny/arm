/********************************************************************

	signal_utils.h
	
	Common DSP functions

********************************************************************/


#ifndef __SIGNAL_UTILS_H_
#define __SIGNAL_UTILS_H_

#include "stdint.h"

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

void repack_adc_data_12bit(uint32_t *data_in, uint32_t *data_out, uint32_t count);
void unpack_data_32_to_16(uint32_t *data_in, uint32_t *data_out, uint32_t input_buffer_size, uint32_t sign_extend);
void unpack_data_32_to_16_two_buf(uint32_t *data_in, uint32_t *datal_out, uint32_t *datah_out, uint32_t input_buffer_size, uint32_t sign_extend);
void unpack_u32_to_u8(uint32_t *src, uint8_t *dst, uint32_t src_byte_offset, uint32_t byte_count);
void pack_u8_to_u32(uint8_t *src, uint32_t *dest, uint32_t dst_byte_offset, uint32_t byte_count);
void depBit(uint32_t *src, uint32_t *dst, uint32_t srcBitNum, uint32_t dstBitNum, uint32_t count);


#ifdef __cplusplus
}
#endif // __cplusplus


#endif //__SIGNAL_UTILS_H_	

