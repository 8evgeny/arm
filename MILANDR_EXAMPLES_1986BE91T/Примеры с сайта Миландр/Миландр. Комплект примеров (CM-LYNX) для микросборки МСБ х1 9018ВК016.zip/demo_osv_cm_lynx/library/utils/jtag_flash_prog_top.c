/********************************************************************
	FLASH device programmer over JTAG using stdio functions.
	Author:	borozdin.a
	
********************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "jtag_flash_prog_top.h"


static FILE *handle;
static uint8_t buffer[FILE_BUFFER_SIZE];
static char user_args[500];
static char str[400];


static char *filename;


//=======================================================//
// Command line parser

#define MAX_ARGC 	20
static char *argv[MAX_ARGC];
static int argc;



//-------------------------------------------------------//
// String into words splitter
//
// Replaces spacing and terminating symbols with '\0'
//-------------------------------------------------------//
uint8_t splitString(char *sourceString, uint16_t sourceLength, char **words, uint8_t maxWordCount)
{
    uint16_t wordCount = 0;
    uint16_t i = 0;
    uint8_t search_for_word = 1;
    uint8_t foundEOM = 0;
    char temp_char;

    while ((i < sourceLength) && (wordCount < maxWordCount) && (foundEOM == 0))
    {
            temp_char = sourceString[i];
            if ((temp_char == ' ') || (temp_char == '\t') || (temp_char == '\n') || (temp_char == '\r'))
            {
                sourceString[i] = '\0';
                search_for_word = 1;
            }
            else if (temp_char == '\0')
            {
                sourceString[i] = '\0';
                foundEOM = 1;
            }
            else
            {
                // Normal char
                if (search_for_word == 1)
                {
                    words[wordCount++] = &sourceString[i];		// Found start position of a word
                    search_for_word = 0;
                }
            }
            i++;
    }
    return wordCount;
}


int16_t getIndexOfKey(char **strArray, uint8_t arraySize, const char *key)
{
    uint8_t i;
    int16_t keyIndex = -1;
    for (i=0; (i<arraySize) && (keyIndex == -1); i++)
    {
        if (strcmp(strArray[i], key) == 0)
            keyIndex = i;
    }
    return keyIndex;
}


int8_t getStringForKey(char **strArray, uint8_t arraySize, const char *key, char**result)
{
    int16_t index = getIndexOfKey(strArray, arraySize, key);
    int8_t resultCode;
    if (index >= 0)
    {
        if (index < arraySize - 1)
        {
            resultCode = 0;
            *result = strArray[index + 1];
        }
        else
        {
            resultCode = -1;
        }
    }
    else
    {
        resultCode = -1;
    }
    return resultCode;
}



int8_t getValueUI32ForKey(char **strArray, uint8_t arraySize, const char *key, uint32_t *result)
{
    int16_t index = getIndexOfKey(strArray, arraySize, key);
    int8_t resultCode;
    if (index >= 0)
    {
        if (index < arraySize - 1)
        {
            resultCode = 0;
            *result = (uint32_t)strtoul(strArray[index + 1], 0, 0);
        }
        else
        {
            resultCode = -1;
        }
    }
    else
    {
        resultCode = -1;
    }
    return resultCode;
}




//=======================================================//

/*
	program -file 1.bin -offset 0x1234 -addr 0x00000000 -size 0x100 -verify
	program -file 1.bin -offset 0x1234 -addr 0x00000000 -verify
	
	read
	
	verify
	
	id
	
	erase

*/





void flash_prog_top_init(void *flash_drv_params)
{
	flash_cmd_init(flash_drv_params);
}




void flash_prog_top_execute(void)
{
	int32_t filesize;
	int32_t read_byte_count;
	int32_t current_byte_count;
	uint32_t device_address;
	uint32_t total_blocks;
	uint32_t current_block;
	int32_t verify_result;
	uint32_t temp32u;
	int32_t temp32;
	uint32_t i;
	uint32_t offset;
	uint32_t file_offset;
	uint32_t total_byte_count;
	uint32_t do_verify;
	int32_t op_program;
	int32_t flash_op_result;
	uint32_t verbose_level;
	
	int c;
	
	
	// Wait for user input
	printf("Input command and press return\n");
	fgets(user_args, sizeof(user_args), stdin);
	
	// Make array of words from command string
	argc = splitString(user_args, strlen(user_args), argv, MAX_ARGC);
	
	// Determine common options
	verbose_level = 2;
	if (getIndexOfKey(argv, argc, "-quiet") != -1)
		verbose_level = 1;
	else if (getIndexOfKey(argv, argc, "-qquiet") != -1)
		verbose_level = 0;
	
	// Determine command
	if (getIndexOfKey(argv, argc, "id") != -1)
	{
		// Reading ID
		flash_op_result = flash_cmd_read_id(buffer, FILE_BUFFER_SIZE, &temp32u);
		if (flash_op_result == 0)
		{
			sprintf(str, "FLASH ID: ");
			offset = 10;
			for(i=0; i<temp32u; i++)
			{
				sprintf(str + offset, "0x%02X ", buffer[i]);
				offset += 5;
			}
			printf("%s\n", str);
		}
		else
		{
			printf("FLASH error while reading ID\n");
		}
	}
	else if (getIndexOfKey(argv, argc, "erase") != -1)
	{
		// Erasing
		
		// Get address in the FLASH (optional, default is chip erase)
		if (getValueUI32ForKey(argv, argc, "-addr", &device_address) < 0)
			temp32u = 0;
		else
			temp32u = 1;
		
		printf("Erasing %s...", (temp32u) ? "sector" : "chip");
		
		if (temp32u)
		{
			// Sector erase	
			flash_op_result = flash_cmd_erase_sector(device_address);
		}
		else
		{
			// Chip erase
			flash_op_result = flash_cmd_erase_all();
		}
		if (flash_op_result == 0)
			printf("OK\n");
		else
			printf("FLASH error while erasing\n");
	}
	else if ( ((temp32 = getIndexOfKey(argv, argc, "program")) >= 0) || (getIndexOfKey(argv, argc, "verify") >= 0) )
	{
		op_program = (temp32 >= 0) ? 1 : 0;
		while(1)
		{
			// Writing data to FLASH
			if (getStringForKey(argv, argc, "-file", &filename) < 0)
			{
				printf("Error: Missing file argument\n");	
				break;
			}
			
			handle = fopen(filename, "rb"); 
			
			if (handle == NULL)
			{
				printf("Cannot open file %s for reading\n", filename);
				break;
			}
			
			fseek(handle, 0, SEEK_END); 	// seek to end of file
			filesize = ftell(handle); 		// get current file pointer
			printf("File open OK. File size = %u bytes\n", filesize);
		
			// Get byte offset in the file (optional, default is 0)
			if (getValueUI32ForKey(argv, argc, "-offset", &file_offset) < 0)
				file_offset = 0;
			
			if (file_offset > filesize)
				file_offset = filesize;
			filesize -= file_offset;
				
			// Get address in the FLASH (optional, default is 0)
			if (getValueUI32ForKey(argv, argc, "-addr", &device_address) < 0)
				device_address = 0;
				
			// Get byte count (optional, default is file size)
			if (getValueUI32ForKey(argv, argc, "-size", &total_byte_count) < 0)
			{
				total_byte_count = filesize;
			}
			else
			{
				if (total_byte_count > filesize)
					total_byte_count = filesize;
			}
				
			// Check if verify is required (or operation is verify)
			if ((getIndexOfKey(argv, argc, "-verify") >= 0) || (op_program == 0))
				do_verify = 1;
			else
				do_verify = 0;
			
			total_blocks = total_byte_count / FILE_BUFFER_SIZE;
			if (total_byte_count % FILE_BUFFER_SIZE)
				total_blocks++;
			current_block = 1;

			printf("%s FLASH with parameters:\n\tfile = %s\n\tfile offset = 0x%08X\n\taddress = 0x%08X\n\tbyte count = %u\n\tverify = %u\n", 
					(op_program) ? "Program" : "Verify", filename, file_offset, device_address, total_byte_count, do_verify);
			fseek(handle, file_offset, SEEK_SET); 	// seek to the offset
			
			while (total_byte_count > 0)
			{
				current_byte_count = (total_byte_count < FILE_BUFFER_SIZE) ? total_byte_count : FILE_BUFFER_SIZE;
				
				// Read data from file
				read_byte_count = fread(buffer, sizeof(uint8_t), current_byte_count, handle);
				if (read_byte_count != current_byte_count)
				{
					printf("Cannot read required number of bytes from file");
					break;
				}
			
				// Program flash					
				if (verbose_level >= 2)
					printf("Block %u of %u ... ",current_block, total_blocks);
			
				if (op_program)
				{
					flash_op_result = flash_cmd_write(device_address, buffer, current_byte_count);
					if (flash_op_result != 0)
					{
						printf("FLASH error while writing data\n");	
						break;
					}
				}
				// Verify flash
				if (do_verify)
				{
					flash_op_result = flash_cmd_verify(device_address, buffer, current_byte_count, &verify_result);
					if (flash_op_result != 0)
					{
						printf("FLASH error while verifying data\n");	
						break;
					}
				}
				else
				{
					verify_result = 0;	
				}
	
				if (verify_result != 0)
				{
					printf("FAIL\nVerify failed for block %u\n", current_block);
					break;
				}	
				else
				{
					if (verbose_level >= 2)
						printf("OK\n");
					else if (verbose_level >= 1)
						printf("#");	
					else if (current_block % 10 == 0)
						printf("#");
				}
				current_block++;
				total_byte_count -= current_byte_count;
				device_address += current_byte_count;
			}
			break;	
		}	// while(1)
	}
	else if (getIndexOfKey(argv, argc, "read") >= 0)
	{
		while(1)
		{
			// Reading data from FLASH
			if (getStringForKey(argv, argc, "-file", &filename) < 0)
			{
				printf("Error: Missing file argument\n");	
				break;
			}
			
			handle = fopen(filename, "wb"); 
			
			if (handle == NULL)
			{
				printf("Cannot open file %s for writind\n", filename);
				break;
			}
			
			// Get address in the FLASH (mandatory)
			if (getValueUI32ForKey(argv, argc, "-addr", &device_address) < 0)
			{
				printf("Error: Missing address argument\n");
				break;
			}
				
			// Get byte count (mandatory)
			if (getValueUI32ForKey(argv, argc, "-size", &total_byte_count) < 0)
			{
				printf("Error: Missing size argument\n");
				break;
			}
			
			printf("Reading FLASH with parameters:\n\tfile = %s\n\taddress = 0x%08X\n\tbyte count = %u\n", 
					filename, device_address, total_byte_count);
					
			total_blocks = total_byte_count / FILE_BUFFER_SIZE;
			if (total_byte_count % FILE_BUFFER_SIZE)
				total_blocks++;
			current_block = 1;

			while (total_byte_count > 0)
			{
				current_byte_count = (total_byte_count < FILE_BUFFER_SIZE) ? total_byte_count : FILE_BUFFER_SIZE;
				
				if (verbose_level >= 2)
					printf("Block %u of %u ... ",current_block, total_blocks);
				
				// Read data from FLASH
				flash_op_result = flash_cmd_read(device_address, buffer, current_byte_count);
				if (flash_op_result != 0)
				{
					printf("FLASH error while reading data\n");	
					break;
				}
				
				// Write data to file
				read_byte_count = fwrite(buffer, sizeof(uint8_t), current_byte_count, handle);
				if (read_byte_count != current_byte_count)
				{
					printf("Cannot write required number of bytes to file\n");
					break;
				}
				if (verbose_level >= 2)
					printf("OK\n");
				else if (verbose_level >= 1)
					printf("#");	
				else if (current_block % 10 == 0)
					printf("#");
					
				
				current_block++;
				total_byte_count -= current_byte_count;
				device_address += current_byte_count;
			}
			
			break;	
		}	// while(1)
	}
	else if (getIndexOfKey(argv, argc, "reboot") >= 0)
	{
		system_restart();
	}
	
	if (handle)
	{
		fclose(handle);
	}
	
	/*
	if (strcmp(user_args, "id") == 0)
	{
		// Try to read ID
		flash_read_id(buffer, FILE_BUFFER_SIZE, &temp32u);
		sprintf(str, "FLASH ID: ");
		offset = 0;
		for(i=0; i<temp32u; i++)
		{
			sprintf(str + offset, "0x%02X ", buffer[i]);
			offset += 5;
		}
		//sprintf(str, "FLASH ID: 0x%x 0x%x\n", buffer[2], buffer[3]);
		printf("%s\n", str);
	}
	else if (strcmp(user_args, "program") == 0)
	{
		handle = fopen(filename, "rb"); 
		if (handle == NULL)
		{
			printf("Cannot open file %s for reading", filename);
		}
		else
		{
			fseek(handle, 0, SEEK_END); 	// seek to end of file
			filesize = ftell(handle); 		// get current file pointer
			fseek(handle, 0, SEEK_SET); 	// seek back to beginning of file
			printf("Open file %s OK \nSize = %u bytes\n", filename, filesize);
	
			printf("Erasing ...", filename, filesize);
			flash_erase_all();
			printf("OK\nProgramming:\n");
	
			device_address = 0;
			total_blocks = filesize / FILE_BUFFER_SIZE;
			if (total_blocks % FILE_BUFFER_SIZE)
				total_blocks++;
			current_block = 1;
	
			while (filesize > 0)
			{
				current_byte_count = (filesize < FILE_BUFFER_SIZE) ? filesize : FILE_BUFFER_SIZE;
				read_byte_count = fread(buffer, sizeof(uint8_t), current_byte_count, handle);
				if (read_byte_count != current_byte_count)
				{
					printf("Cannot read required number of bytes from file");
					break;
				}
				
				// Program flash					
				printf("Block %u of %u ... ",current_block, total_blocks);
				
				flash_write(device_address, buffer, current_byte_count);
				verify_result = flash_verify(device_address, buffer, current_byte_count);
				if (verify_result != 0)
				{
					printf("FAIL\nVerify failed for block %u", current_block);
					break;
				}
		
				printf("OK\n");
				current_block++;
				filesize -= current_byte_count;
				device_address += current_byte_count;
			}
		}
	}
	else if (strcmp(user_args, "reboot") == 0)
	{
		system_restart();
	}
	else
	{
		printf("Unknown command\n");
	} */
	printf("\nDone!\n\n");
}




