/********************************************************************
	FLASH device programmer over JTAG using stdio functions.
	Author:	borozdin.a
	
********************************************************************/


#ifndef __JTAG_FLASH_PROG_TOP_H_
#define __JTAG_FLASH_PROG_TOP_H_


#include "stdint.h"

#define FILE_BUFFER_SIZE	4096		// bytes

#define FLASH_OK		0
#define FLASH_ERROR		-1


/*
	Must be compiled with CHAR8 due to stdio functions (fread, etc)
	
	
	Commands:
	
	
	0. Reading ID from FLASH - recommended to start with this command
	Arguments [mandatory]: 
		none
	Arguments [optional]: 
		none
	Output: 
		Prints device-specific ID code into log window.
	Examples:
		id
	
	
	1. Erase device. Whole device can be erased, or a sector with specified address.
	Arguments [mandatory]: 
		none
	Arguments [optional]: 
		-addr x 
	Output: 
		Erased device or sector
	Examples:
		erase
		erase -addr 0x001FFFF0
		
		
	2. Read data from FLASH
	Arguments [mandatory]: 
		-file x (file on host file system to save data to)
		-addr x (address in the FLASH to start with)
		-size x (count of bytes to read)
	Arguments [optional]: 
		-quiet (reduces log output)
	Output:
		binary file with data read from FLASH device
	Examples:
		read -file E:/Temp/1.bin -addr 0 -size 40000 -quiet
		read -file E:/Temp/1.bin -addr 0x001FFFF0 -size 16
		
		
	3. Program data to FLASH
	Arguments [mandatory]: 
		-file x (file on host file system to get data from)
	Arguments [optional]: 
		-offset x (byte offset in the file to start from, default is 0)
		-addr x (address in the FLASH to start with, default is 0)
		-size x (count of bytes to write, default is file size)
		-verify (if set, written data chunk will be verified)
		-quiet (reduces log output)
	Output:
		FLASH device programmed with data from file on host file system
	Examples:
		program -file E:/Temp/mem_test.ldr -verify
		program -file E:/Temp/mem_test.ldr -addr 0x1000 -verify
		program -file E:/Temp/mem_test.ldr -addr 0x1000 -size 1288 -verify
		program -file E:/Temp/mem_test.ldr -verify -quiet
		program -file E:/Temp/4.bin -addr 0x001FFFF0 -verify
	
	
	4. Verify data in file and FLASH device
	Arguments [mandatory]: 
		-file x (file on host file system to get data from)
	Arguments [optional]: 
		-offset x (byte offset in the file to start from, default is 0)
		-addr x (address in the FLASH to start with, default is 0)
		-size x (count of bytes to write, default is file size)
		-quiet (reduces log output)
	Output: 
		Log message providing verify result
	Examples:
		verify -file E:/Temp/1.bin -addr 0x001FFFF0 -size 16
		verify -file E:/Temp/mem_test.ldr -addr 0x1000 -size 1288
	
	5. Reboot CPU
	Arguments [mandatory]: 
		none
	Arguments [optional]: 
		none
	Output:
		CPU is rebooted and (if enabled) starts to load and execute just programmed image.
		Note, that debugger thinks, that DSP continues executing jtag_flash_programmer.
	Examples:
		reboot
		
		
	 Added -qquiet key to reduce log output even more (useful on slow machines)
	
*/


// These functions are external to flash_prog_top 
// and should be provided by other source files
extern void flash_cmd_init(void *params);
extern int32_t flash_cmd_erase_all(void);
extern int32_t flash_cmd_erase_sector(uint32_t flash_address);
extern int32_t flash_cmd_read_id(uint8_t *buffer, uint32_t buffer_size, uint32_t *read_size);
extern int32_t flash_cmd_write(uint32_t flash_address, uint8_t *buffer, uint32_t byte_count);
extern int32_t flash_cmd_read(uint32_t flash_address, uint8_t *buffer, uint32_t byte_count);
extern int32_t flash_cmd_verify(uint32_t flash_address, uint8_t *buffer, uint32_t byte_count, int32_t *result);
extern int32_t system_restart(void);

// These functions must be called from main.
void flash_prog_top_init(void *flash_drv_params);
void flash_prog_top_execute(void);





#endif //__JTAG_FLASH_PROG_TOP_H_
