
#include "sine_generator.h"
#include <math.h>
#ifndef PI
	#define PI 3.14159265358979323846
#endif


void sine_generator_init(float signal_freq, float sample_freq, float zero_point, float ampl_pp, sine_generator_t *g)
{
	g->sample_period = 1 / sample_freq;
	g->signal_period = 1 / signal_freq;
	g->signal_frequency = signal_freq;
	g->time = 0;
	g->zero_point = zero_point;
	g->ampl_pp = ampl_pp;
}


float sine_generator_get_sample(sine_generator_t *g)
{
	float phase = g->time * g->signal_frequency;	// time / period	
	float sample = sin (2 * PI * phase);
	g->time += g->sample_period;
	if (g->time >= g->signal_period)
		g->time -= g->signal_period;
	sample *= g->ampl_pp / 2;
	sample += g->zero_point;
	return sample;
}
