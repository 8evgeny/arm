
#include <string.h>
#include <stdlib.h>
#include "arg_parser.h"



//-------------------------------------------------------//
// String into words splitter
//
// Replaces spacing and terminating symbols with '\0'
//-------------------------------------------------------//
uint8_t splitString(char *sourceString, uint16_t sourceLength, char **words, uint8_t maxWordCount)
{
    uint16_t wordCount = 0;
    uint16_t i = 0;
    uint8_t search_for_word = 1;
    uint8_t foundEOM = 0;
    char temp_char;

    while ((i < sourceLength) && (wordCount < maxWordCount) && (foundEOM == 0))
    {
            temp_char = sourceString[i];
            if ((temp_char == ' ') || (temp_char == '\t') || (temp_char == '\n') || (temp_char == '\r'))
            {
                sourceString[i] = '\0';
                search_for_word = 1;
            }
            else if (temp_char == '\0')
            {
                sourceString[i] = '\0';
                foundEOM = 1;
            }
            else
            {
                // Normal char
                if (search_for_word == 1)
                {
                    words[wordCount++] = &sourceString[i];		// Found start position of a word
                    search_for_word = 0;
                }
            }
            i++;
    }
    return wordCount;
}



int16_t getIndexOfKey(char **strArray, uint8_t arraySize, const char *key)
{
    uint8_t i;
    int16_t keyIndex = -1;
    for (i=0; (i<arraySize) && (keyIndex == -1); i++)
    {
        if (strcmp(strArray[i], key) == 0)
            keyIndex = i;
    }
    return keyIndex;
}


int8_t getStringForKey(char **strArray, uint8_t arraySize, const char *key, char**result)
{
    int16_t index = getIndexOfKey(strArray, arraySize, key);
    int8_t resultCode;
    if (index >= 0)
    {
        if (index < arraySize - 1)
        {
            resultCode = 0;
            *result = strArray[index + 1];
        }
        else
        {
            resultCode = -1;
        }
    }
    else
    {
        
        resultCode = -1;
    }
    return resultCode;
}



int8_t getValueUI32ForKey(char **strArray, uint8_t arraySize, const char *key, uint32_t *result)
{
    int16_t index = getIndexOfKey(strArray, arraySize, key);
    int8_t resultCode;
    if (index >= 0)
    {
        if (index < arraySize - 1)
        {
            resultCode = 0;
            *result = (uint32_t)strtoul(strArray[index + 1], 0, 0);
        }
        else
        {
            resultCode = -1;
        }
    }
    else
    {
        resultCode = -1;
    }
    return resultCode;
}


int8_t decodeKey(char *key, key_value_t *table, uint32_t table_size, uint32_t *val)
{
	int8_t resultCode = -1;
	uint32_t keyIndex;
	uint32_t i;
	for (i=0; i<table_size; i++)
	{
        if (strcmp(table[i].key, key) == 0)
        {
        	*val = table[i].val;
        	resultCode = 0;
        	break;
        }
	}
	return resultCode;
}

