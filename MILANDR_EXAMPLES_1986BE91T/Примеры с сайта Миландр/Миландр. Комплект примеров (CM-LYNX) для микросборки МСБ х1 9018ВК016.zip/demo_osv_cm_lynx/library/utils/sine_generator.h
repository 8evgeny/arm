#ifndef __SINE_GENERATOR_H__
#define __SINE_GENERATOR_H__

#include "stdint.h"

//----------- Definitions ----------//

typedef struct {
	float sample_period;
	float signal_period;
	float signal_frequency;
	float time;
	float zero_point;
	float ampl_pp;
} sine_generator_t;



//----------- Prototypes -----------//

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

	void sine_generator_init(float signal_freq, float sample_freq, float zero_point, float ampl_pp, sine_generator_t *g);
	float sine_generator_get_sample(sine_generator_t *g);

#ifdef __cplusplus
}
#endif // __cplusplus

//----------- Externals ------------//



#endif //__SINE_GENERATOR_H__	
