// Please do not use this header file in your project!
// This is the sample of config header file.
//
// To use HAL, you must create in your project "1967VN044_HAL_config.h"
// header file and define XTI_KHZ macro



//#define XTI_KHZ					25000					// External XTI clock in kHz


