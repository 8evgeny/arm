

void _LFSR32_cycle_fast(int seed, int count);
/*
.extern _fill_mem32;
.extern _fill_mem64;
.extern _fill_mem128;
.extern _fill_mem_with_random;

.extern _compx_mem32;
.extern _compx_mem64;
.extern _compx_single_word;
.extern _compx_long_word_mem;
.extern _compx_quad_word_mem;
.extern _compx_single_word_neq;
.extern _check_memory_by_quad;

.extern _memcpy32;
.extern _copy_mem_core_single;
.extern _copy_mem_core_quad;

.extern _LFSR32;
.extern _LFSR32_fast;
.extern _LFSR32_cycle_fast;

*/
//.extern _LFSR32;
//.extern _LFSR32_fast;


