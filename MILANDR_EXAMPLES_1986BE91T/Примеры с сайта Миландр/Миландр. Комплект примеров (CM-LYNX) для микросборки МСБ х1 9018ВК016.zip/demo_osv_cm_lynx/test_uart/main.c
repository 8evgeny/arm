#include "board.h"

static void uart_init(void);
static void uart_send_data(uint8_t *data, uint32_t len_data);


//обработчик прервывания при появлении новых входных данных
__attribute__((interrupt))
static void UART0_RX_Handler(void)
{
	uint32_t c;
	if(LX_UART0->UFLAG.b.URXFE == 0) //если fifo не пуcтой, читаем символ
	{
		c = LX_UART0->UDR;

	}
}


int main()
{
	uint32_t i;
	uint8_t uart_tx_data;
	//инициализация отладочной платы
	BRD_init();
	//инициализация светодиодов
	Init_LEDS_Port();

	//инициализация UARTa
	uart_init();

	while(1)
	{
		for (i = 0; i < 255; i++)
		{
			uart_tx_data = i;
			uart_send_data(&uart_tx_data, 1);
			BRD_LED_toggleState(brdLed1);
			wait_msec(100);
		}
	}
}
//инициализация интерфейса UART0
static void uart_init(void)
{
	UART_Init_type UARTInit; //структура для инициализации UART

	UARTInit.BitRate = 115200;
	UARTInit.OverSampling = UART_OverSampling_Normal;
	UARTInit.WorkMode = UART_Mode_TxRx;
	UARTInit.WordLength = UART_WordLen_8bit;
	UARTInit.StopBits = UART_Stop_1bit;
	UARTInit.ParityMode = UART_Parity_Off;
	UARTInit.FIFOSize = UART_FIFOSize_Byte;
	UARTInit.TXDMode = UART_TXD_Direct;
	UARTInit.DMACtrlErr = UART_DMACtrl_Dis;

	//инициализации ножек процессора для работы альтернативной функции
	HAL_GPIO_Init (LX_GPIO_PA,  GPIO_PIN_0 | GPIO_PIN_1, GPIO_PinMode_Alt); // GPIO_PIN_x, x - зависит от выбранного UART
	HAL_UART_Init (LX_UART0, &UARTInit);

	HAL_UART_ITConfig(LX_UART0, UART_IT_RX, UART_IT_En ); //разрешение генерации прерывания при появлении входных данных на в буфере UART
	HAL_Interrupt_Enable(intUART0, UART0_RX_Handler); //настройка прервываний от UART0, указатель на обработчик прерывния от UART0.

}
//функция отправляет данные буфера data по UART
static void uart_send_data(uint8_t *data, uint32_t len_data)
{
	HAL_UART_Send(LX_UART0, data, len_data);
}
