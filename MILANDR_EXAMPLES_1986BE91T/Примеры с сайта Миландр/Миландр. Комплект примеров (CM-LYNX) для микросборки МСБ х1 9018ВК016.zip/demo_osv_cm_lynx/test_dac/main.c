/*****************************************************************************
 * test_dac.c
 *****************************************************************************/


#include "board.h"
#include "5101HB015.h"
#include "5101HB015_SPI_1967VC3.h"
#include "sine_generator.h"
#include "signal_utils.h"


#define N	2048

static uint32_t link_tx_dma_tcb[4] __attribute__((aligned(4))); //конфигурация для TCB регистра DMA
unsigned int	dac_tx_buffer[N]__attribute__((aligned(4)));  //буфер для передачи данных по LVDS в ЦАП
unsigned char spi_dac_cmd; // данные для предачи в ЦАП по SPI


static void dac_spi_send_data(unsigned char address, unsigned char byte_count, unsigned char *data);
static void adc_init(void);
static void dac_init_spi();
static void dac_link_dma_init(uint8_t updown_en);
static void updown_init();

__attribute__((interrupt))
static void DMA_LINK_DAC_Handler()  //обработчик прерывания DMA от LINK порта ЦАПа
{
	BRD_LED_toggleState(brdLed2); //при срабатывании прерывания LINK порта ЦАПа, мигает светодиод 0
}

int main( void )
{
	uint8_t updown_en;
	unsigned int i;
	float samp_flt;
	unsigned int samp_int;
	sine_generator_t g;



	//инициализация отладочной платы
	BRD_init();
	//инициализация светодиодов
	Init_LEDS_Port();

	//инициализация spi для работы с ЦАПом
	dac_init_spi();

	//запись конфигурации в регистры ЦАПа по spi
	spi_dac_cmd = (1<<5); //програмный сброс
	dac_spi_send_data(0x00, 1, &spi_dac_cmd);

	spi_dac_cmd = (0<<6);		// включение  режима DDR mode
	//spi_dac_cmd = (1<<6);		// включение  режима SDR mode
	//dac_cmd[0] |= (1<<3);		// включение  генерации CLK output
	dac_spi_send_data(0x02, 1, &spi_dac_cmd);

	spi_dac_cmd = (1<<6);		// обходит схемы синхронизации данных. Данные отбираются с использованием тактового сигнала ЦАП (CLK ±)
	dac_spi_send_data(0x16, 1, &spi_dac_cmd);

	spi_dac_cmd = (1<<0);		// включение некалиброванной работы
	dac_spi_send_data(0x0F, 1, &spi_dac_cmd);


	// Установка L0ACKI в 1
	LX_GPIO_PC->ALT.CLR = (1 << 25);
	LX_GPIO_PC->DDR.SET = (1 << 25);
	LX_GPIO_PC->DR.SET = (1 << 25);

	// создание синусоидального сигнала
	// для простого сигнала ЦАПа младшие разряды семлов сигнала не заполнять (частота дискретизации должна быть ниже в 2 раза)
	sine_generator_init(10, 1000, 0, 50000, &g);
	for (i=0; i<N; i++)
	{
		samp_flt = sine_generator_get_sample(&g);
		samp_int = (unsigned int)samp_flt;
		//dac_tx_buffer[i] = __builtin_fdep(dac_tx_buffer[i], samp_int, (0 << 8) | 16);
		dac_tx_buffer[i] = __builtin_fdep(0x00, samp_int, (0 << 8) | 16);

		samp_flt = sine_generator_get_sample(&g);
		samp_int = (unsigned int)samp_flt;
		dac_tx_buffer[i] = __builtin_fdep(dac_tx_buffer[i], samp_int, (16 << 8) | 16);
	}

	//АЦП обеспечивает тактирование ЦАПа, поэтому инициализируем АЦП
	adc_init();



#if 1 //простая генерация сигнала ЦАПом
	updown_en = 0;
	//настройка LVDS для ЦАПа, запуск DMA
	dac_link_dma_init(updown_en);

#else

	//генерация сигнала с использование модуля updown
	// постоянный уровень на входе в конвертер дает несущую в конвертере
	for (i=0; i<128; i++)
		dac_tx_buffer[i] = 0x7FFF0000;

	updown_en = 1;
	//инициализация блока UPDOWN
	updown_init();
	//настройка LVDS для ЦАПа, запуск DMA
	dac_link_dma_init(updown_en);


#endif

	BRD_LED_setState(brdLed1);


	while(1)
	{
		asm("nop;;");
		asm("nop;;");
		asm("nop;;");
		asm("idle;;");
		asm("nop;;");
	}
}


static void dac_link_dma_init(uint8_t updown_en)
{
	unsigned int dma_ch_num;
	LinkTxEx_type link_dac_ini_str;   //структура для описания внешенего устройства с LINK интерфейсом (кому передаем)
	LinkTx_Init_type link_tx_ini_str; //структура для инициализации передачтика LINK порта

	// канал DMA
	dma_ch_num = 4;
	//Деинициализация передатчика LINK порта  0
	HAL_LinkTx_Disable(0);

	link_tx_ini_str.DataSize = Link_DataSize_16bit;
	link_tx_ini_str.ClkSource = Link_TxClk_Slave;
	link_tx_ini_str.CheckSum = Link_CheckSum_Dis;
	link_tx_ini_str.CheckBCMPO = Link_CheckBCMP_Dis;
	link_tx_ini_str.TOIntEn = Link_TOIT_Dis;

	link_dac_ini_str.CheckACKI = Link_CheckACKI_Dis;
	link_dac_ini_str.Tcode = Link_Tcode_Dis;
	if (updown_en)
		link_dac_ini_str.TxSource = Link_TxDest_UpDown; //данные из буфера UPDOWN
	else
		link_dac_ini_str.TxSource = Link_TxDest_Buff; //данные из буфера LINK - порта


	//инициализация передатчик LINK порта  0
	HAL_LinkTx_Enable(0, &link_tx_ini_str,  &link_dac_ini_str );

	//деиницализация  DMA_DAC_TX_CH - канала DMA
	HAL_DMA_Stop(dma_ch_num);
	//Очистка источника опроса DMA_DAC_TX_CH - канала
	HAL_DMA_RqstClr(dma_ch_num);


	if (updown_en)
		HAL_DMA_RqstSet( dma_ch_num, dmaUPDOWN1); //установка нового источника оспроса для канала dma_ch_num - UPDOWN модуль
	else
		HAL_DMA_RqstSet( dma_ch_num, dmaSTD ); //установка нового источника оспроса для канала dma_ch_num dmaSTD


	//конфигураия регистра TCB для канала -  dma_ch_num
	link_tx_dma_tcb[0] = (uint32_t)dac_tx_buffer;  //буфер источник
	link_tx_dma_tcb[1] = (N << 16) | 4; //количество данных, размер порции
	link_tx_dma_tcb[2] = 0;
	link_tx_dma_tcb[3] = TCB_INTMEM | TCB_QUAD | TCB_CHAIN | TCB_HPRIORITY | ((unsigned int )&link_tx_dma_tcb >> 2) |
						 HAL_DMA_GetTCBChannelDest( dma_ch_num ) | TCB_INT;  //параметры передачи



	//разрешение прерывания от канла DMA 4, передача указателя на функцию обработчик прерывания
	HAL_Interrupt_Enable(intDMA4, (void *)DMA_LINK_DAC_Handler);

	//запуск работы канала 4  DMA
	HAL_DMA_WriteDC(dma_ch_num,  &link_tx_dma_tcb);
}

//функция для расчета логарифма по основанию 2
static int updown_log2 (unsigned int val)
{
    int ret = -1;
    while (val != 0)
    {
        val >>= 1;
        ret++;
    }
    return ret;
}

// Расчет сдвига  S для сдвигателя производится по следующей
// S =  B_IN - B_OUT + Kf * log_2(D), где
// Kf - длина фильтра (3, 5 or 7),
// D - коэффициент децимации/интерполяции
// B_IN - разрядность входных данных (from ADC, или данных для ЦАПа)
// B_OUT - разрядность выходных данных
static unsigned int updown_get_shift_amount(int b_in, int b_out, int decimation_k, int filter_length)
{
	int f_length;
	int log2_res;
	int result;
	switch (filter_length)
	{
		case UPDOWN_FiltersStage_3:
			f_length = 3;	break;
		case UPDOWN_FiltersStage_5:
			f_length = 5;	break;
		case UPDOWN_FiltersStage_7:
			f_length = 7;	break;
		default:
			f_length = 5;	// wrong argument
	}
	log2_res = updown_log2(decimation_k);

	result = b_in - b_out + f_length * log2_res;
	if (result < 0) result = 0;
	if (result > 0x7F) result = 0x7F;
	return result;
}

//расчет шага по таблице коэффициетов гетеродина
// sample_freq - частота дискретизации
// heterodyne_freq - частота гетеродина
static uint16_t updown_get_freq_table_step(float sample_freq, float heterodyne_freq)
{
	uint32_t step;
	float k = sample_freq / heterodyne_freq;
	step = 0x10000 / k;
	if (step > 0x10000)
		step = 0;
	return step;
}


static void updown_init()
{
	float f_samp;
	float f_heterodyne;
	unsigned int shift_amount;
	unsigned int heter_freq_step;
	unsigned int interpolation_k;
	unsigned int filter_length;
	UPDOWN_Init_type updown1_ini_str;

	f_samp = 100000000;
	f_heterodyne = 1000000;

	//коэффициент интерполяции, должен быть степенью 2 и большим или равным 4
	interpolation_k = 16;
	// Длина CIC фильра интерполятора
	filter_length = UPDOWN_FiltersStage_5;

	//расчет шага по таблице коэффициентов
	heter_freq_step = updown_get_freq_table_step(f_samp, f_heterodyne);
	//расчет величины сдвига для свигателя, такой чтобы разрядность входных и выходных данных была равна 16 бит
	shift_amount = updown_get_shift_amount(16, 16,  interpolation_k, filter_length);



	//заполнение структуры для инициализации
	updown1_ini_str.Mode = UPDOWN_Mode_Up;  //режим работы модуля - DOWN
	updown1_ini_str.LinkX = UPDOWN_Link_0;    //номер LINK - порта с которым будет работать модуль UPDOWN
	updown1_ini_str.FiltersStage = filter_length;
	updown1_ini_str.Round = UPDOWN_Round_Off;
	updown1_ini_str.Shift = shift_amount;
	updown1_ini_str.FifoMode =  UPDOWN_FifoMode_LowWord_QI;
	updown1_ini_str.Coefficient = interpolation_k;
	updown1_ini_str.CntMode = UPDOWN_CntMode_Off;
	updown1_ini_str.Step = heter_freq_step; //шаг по таблице коэффициентов гетеродина
	updown1_ini_str.Cnt = 0;

	//инициализация передатчика модуля UPDOWN1
	HAL_UPDOWN_Init((UPDOWN_type *)LX_UPDOWN1, &updown1_ini_str);

}

static void dac_init_spi()
{

	SPI_Init_type spi_ini_str;
	uint32_t spi_dac_pins;

	spi_ini_str.CSNum = 1;
	spi_ini_str.WordSize = 8;
	spi_ini_str.CLK_Polarity = SPI_CLK_Polarity_High;
	spi_ini_str.CLK_Phase = SPI_CLK_Phase_Negedge;
	spi_ini_str.FirstBit = SPI_FirstBit_MSB;
	spi_ini_str.CLK_Prescaler = 99;
	spi_ini_str.Mode = SPI_Mode_Master;
	spi_ini_str.CS_Hold = SPI_CS_Unhold;
	spi_ini_str.CS_Hold_Delay = 3;
	spi_ini_str.CS_Active = SPI_CS_Active_Low;
	spi_ini_str.LoopBack = SPI_LoopBack_Off;

	spi_dac_pins = GPIO_PIN_4 |	//CLK
				   GPIO_PIN_5 |//DO
				   GPIO_PIN_6 |//DI
				   GPIO_PIN_8; //CS1



	HAL_GPIO_Init (LX_GPIO_PA, spi_dac_pins, GPIO_PinMode_Alt);
	HAL_SPI_DeInit(LX_SPI0);
	HAL_SPI_Init (LX_SPI0, &spi_ini_str);



}

static void dac_spi_send_data(unsigned char address, unsigned char byte_count, unsigned char *data)
{

	unsigned char i;
	unsigned char k = 0;
	unsigned char rx_data;
	address &= 0x1F;
	byte_count--;
	byte_count &= 0x3;
	address |= (0<<7) | (byte_count << 5);
	LX_SPI0->SPCR1.b.HOLDCS = 1;
	HAL_SPI_SendOnly(LX_SPI0, &address, 1);
	do
	{
		HAL_SPI_SendOnly(LX_SPI0, &data[k],  1);
		k++;
	}
	while(byte_count--);
	LX_SPI0->SPCR1.b.HOLDCS = 0;
}

//инициализация АЦП 0 и 1 по spi
static void adc_init(void)
{
	ADC5101HB015_config_t adc_cfg; //структура для записи конфигурации АЦП
	ADC5101HB015_hw_config_t adc_spi_cfg[2]; //структура для настройки SPI АЦП


	//задание выводов SPI интерфейса АЦП 0 и 1
	adc_spi_cfg[0].port = LX_GPIO_PC;
	adc_spi_cfg[0].cs_bit = (1 << 2);			// FLAG[2]
	adc_spi_cfg[0].clk_bit = (1 << 0);			// FLAG[0]
	adc_spi_cfg[0].mosi_bit = (1 << 3);			// FLAG[3]
	adc_spi_cfg[0].miso_bit = (1 << 3);
	adc_spi_cfg[0].power_down_bit = (1 << 24);	// L0ACKO
	adc_spi_cfg[0].core_freq_khz = CORE_FREQ_KHZ;

	adc_spi_cfg[1].port = LX_GPIO_PC;
	adc_spi_cfg[1].cs_bit = (1 << 2);			// FLAG[2]
	adc_spi_cfg[1].clk_bit = (1 << 1);			// FLAG[1]
	adc_spi_cfg[1].mosi_bit = (1 << 3);			// FLAG[3]
	adc_spi_cfg[1].miso_bit = (1 << 3);
	adc_spi_cfg[1].power_down_bit = (1 << 28);	// L1ACKO
	adc_spi_cfg[1].core_freq_khz = CORE_FREQ_KHZ;

	//задание значений регистров АЦП
	adc_cfg.reference_level = ADC5101HB015_REF_1P0;
	adc_cfg.output_format = ADC5101HB015_OUTPUT_LVDS;
	adc_cfg.lvdsen_pin_state = ADC5101HB015_LVDSEN_PIN_HIGH;
	adc_cfg.lvds_current_mode = ADC5101HB015_LVDS_CURRENT_NORMAL;
	adc_cfg.oen_pin_override = ADC5101HB015_OEN_OVERRIDE;
	adc_cfg.common_mode_sel = ADC5101HB015_COMMON_MODE_0P75;

	//инициализация АЦП 0 и 1 (сброс, калибровка, отправка конфигурации регистров по spi)
	ADC5101HB015_init(1, 1, &adc_spi_cfg[0]);
	ADC5101HB015_config(&adc_cfg);

	ADC5101HB015_init(1, 1, &adc_spi_cfg[1]);
	ADC5101HB015_config(&adc_cfg);
}
