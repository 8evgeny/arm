#include "board.h"
#include "tlv320aic23.h"
#include "sine_generator.h"

#define 	AC_BUFF_SIZE		1024  //размер буфера аудиокодека
static uint32_t ssi_dma_rx_tcb[4]__attribute__((aligned(4))); //буфер для записи конфигурации TCB приемника ssi
static uint32_t ssi_dma_tx_tcb[4]__attribute__((aligned(4))); //буфер для записи конфигурации TCB передатчика ssi

unsigned int	aic_tx_buf[AC_BUFF_SIZE] __attribute__((aligned(4))); // буфер AIC для работы DMA


static void init_aic_ssi_spi(void);
static void start_i2s_tx(uint32_t *buf, uint32_t buf_size, uint32_t ch_num, uint32_t *tcb);
static void start_i2s_rx(uint32_t *buf, uint32_t buf_size, uint32_t ch_num, uint32_t *tcb);
static void fill_tx_buffer(uint32_t *buffer, uint32_t num_samples, sine_generator_t *g_left, sine_generator_t *g_right);
int main()
{
	sine_generator_t g_left;
	sine_generator_t g_right;

	//инициализация отладочной платы
	BRD_init();
	//инициализация светодиодов
	Init_LEDS_Port();

	//инициализация интерфейсов SSI и SPI  для работы с аудиокодеком
	init_aic_ssi_spi();

	//инициализация кодека
	init_tlv320aic23();

	#if 0 //выходной сигнал создается с помощью генератора синуса
		sine_generator_init(1000, 16000, 0, 1000, &g_left);  //увеличение амплитуды синуса увеличивает громкость
		sine_generator_init(3000, 16000, 0, 1000, &g_right);
		fill_tx_buffer(aic_tx_buf, AC_BUFF_SIZE, &g_left, &g_right);
		start_i2s_tx(aic_tx_buf, AC_BUFF_SIZE, DMA_CH_AC_TX, &ssi_dma_tx_tcb);
	#else 		//выходной сигнал поступает с микрофона
		tlv320aic23_set_volume(100, 100); //регулировка громкости по spi
		start_i2s_tx(aic_tx_buf, AC_BUFF_SIZE, DMA_CH_AC_TX, &ssi_dma_tx_tcb);
		start_i2s_rx(aic_tx_buf, AC_BUFF_SIZE, DMA_CH_AC_RX, &ssi_dma_rx_tcb);
	#endif


		while(1)
		{
			asm("nop;;");
		}
}


//Запуск передачи данных в AC через DMA
static void start_i2s_tx(uint32_t *buf, uint32_t buf_size, uint32_t ch_num, uint32_t *tcb)
{

	HAL_DMA_Stop(ch_num);
	HAL_DMA_RqstClr(ch_num);
	HAL_DMA_RqstSet(ch_num, dmaSSI0);

	tcb[0] = (uint32_t)buf;
	tcb[1] = (buf_size << 16) | 1;
	tcb[2] = (1 << 16) | 1;
	tcb[3] = (((uint32_t)buf < 0x10000000) ? TCB_INTMEM : TCB_EXTMEM) |
				TCB_NORMAL | TCB_HPRIORITY | TCB_TWODIM |
				TCB_CHAIN | (((uint32_t)tcb) >> 2) | HAL_DMA_GetTCBChannelDest(ch_num);

	HAL_DMA_WriteDC(ch_num, tcb);
}

///Запуск приема данных из AC через DMA (один буфер)
static void start_i2s_rx(uint32_t *buf, uint32_t buf_size, uint32_t ch_num, uint32_t *tcb)
{

	HAL_DMA_Stop(ch_num);
	HAL_DMA_RqstClr(ch_num);
	HAL_DMA_RqstSet(ch_num, dmaSSI0);

	tcb[0] = (uint32_t)buf;
	tcb[1] = (buf_size << 16) | 1;
	tcb[2] = (1 << 16) | 1;
	tcb[3] = (((uint32_t)buf < 0x10000000) ? TCB_INTMEM : TCB_EXTMEM) |
				TCB_NORMAL | TCB_HPRIORITY | TCB_TWODIM |
				TCB_CHAIN | (((uint32_t)tcb) >> 2) | HAL_DMA_GetTCBChannelDest(ch_num);

	HAL_DMA_WriteDC(ch_num, tcb);
}



// инициализация блоков SSI и SPI для работы с аудиокодеком
static void init_aic_ssi_spi()
{
	uint32_t gpio_spi_pins = 0;   //выводы порта А для SPI
	uint32_t gpio_ssi_pins = 0;   //выводы порта А для SSI
	SPI_Init_type aic_spi_ini_str; //структура для инициализации SPI
	AUDIO_I2S_type ssi_ini_str;

	//Настройка на альтернативную функцию Выводов порта А
	gpio_ssi_pins = GPIO_PIN_13 |
						GPIO_PIN_14 |
						GPIO_PIN_15 |
						GPIO_PIN_16 |
						GPIO_PIN_17 |
						GPIO_PIN_18;
	HAL_GPIO_Init (LX_GPIO_PA,  gpio_ssi_pins , GPIO_PinMode_Alt);


	// Reset FIFOs
	LX_AUDIO0->SICR0.b.RST = 1;
	LX_AUDIO0->SICR0.b.RST = 0;

	// Setup SSI TX
	LX_AUDIO0->SICR2.b.ERPL = 1; //разрешение воспроизведения
	LX_AUDIO0->I2S_T_CR.word = (1 << I2S_TCR_TEN_P) |		// Transmitter enable
						(1 << I2S_TCR_MODE_P) | 	// DSP mode;
						(31 << I2S_TCR_DSS_P) |		// 32 bit
						(1 << I2S_TCR_PACKH_P);		//

	// Setup SSI RX
	LX_AUDIO0->SICR2.b.EREC = 1;
	LX_AUDIO0->I2S_R_CR.word = (1 << I2S_RCR_REN_P) |		// Receiver enable
							(1 << I2S_RCR_MODE_P) |		// DSP mode
							(31 << I2S_RCR_DSS_P);		// 32 bit


	//настройка SPI
	// Установка альтернативной функции для выводов порта А
	gpio_spi_pins = GPIO_PIN_4 |
					GPIO_PIN_5 |
					GPIO_PIN_6 |
					GPIO_PIN_11 ;  //cs4
	HAL_GPIO_Init (LX_GPIO_PA,  gpio_spi_pins , GPIO_PinMode_Alt);

	//конфигурация SPI0 для работы с аудиокодеком
	aic_spi_ini_str.WordSize = 16;
	aic_spi_ini_str.CLK_Polarity = SPI_CLK_Polarity_High;
	aic_spi_ini_str.CLK_Phase = SPI_CLK_Phase_Negedge;
	aic_spi_ini_str.FirstBit = SPI_FirstBit_MSB;
	aic_spi_ini_str.CSNum = 4;
	aic_spi_ini_str.CLK_Prescaler = 99;
	aic_spi_ini_str.Mode = SPI_Mode_Master;
	aic_spi_ini_str.CS_Hold = SPI_CS_Unhold;
	aic_spi_ini_str.CS_Hold_Delay = 0;
	aic_spi_ini_str.CS_Active = SPI_CS_Active_Low;
	aic_spi_ini_str.LoopBack = SPI_LoopBack_Off;

	HAL_SPI_Init (LX_SPI0, &aic_spi_ini_str);
}


//заполнение буфера передатчика синусом
static void fill_tx_buffer(uint32_t *buffer, uint32_t num_samples, sine_generator_t *g_left, sine_generator_t *g_right)
{
	unsigned int samp_int, i;
	float samp_flt;
	for (i=0; i<num_samples; i++)
	{
		samp_flt = sine_generator_get_sample(g_left);
		samp_int = (unsigned int)samp_flt;
		buffer[i] = __builtin_fdep(buffer[i], samp_int, (16 << 8) | 16);

		samp_flt = sine_generator_get_sample(g_right);
		samp_int = (unsigned int)samp_flt;
		buffer[i] = __builtin_fdep(buffer[i], samp_int, (0 << 8) | 16);
	}
}

//функция для отправки конфигурации на кодек по SPI
//data_tx - данные для отправки
uint32_t tlv320aic23_spi_send_receive(uint32_t  data_tx)
{
	uint32_t data_rx;
	HAL_SPI_SendAndReceive(LX_SPI0, &data_tx, &data_rx, 1);
	return data_rx;
}
