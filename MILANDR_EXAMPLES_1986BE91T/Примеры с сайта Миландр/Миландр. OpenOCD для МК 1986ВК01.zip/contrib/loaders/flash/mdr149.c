/***********************************************************************/
/*  This file is part of the ARM Toolchain package                     */
/*  Copyright KEIL ELEKTRONIK GmbH 2003 - 2010                         */
/***********************************************************************/
/*                                                                     */
/*  FlashDev.C:  Flash Programming Functions adapted                   */
/*               for ST Microelectronics STM32F10x Flash               */
/*                                                                     */
/***********************************************************************/

//#include "..\FlashOS.H"        // FlashOS Structures
#include "cm4ikmcu.h"

typedef volatile unsigned char vu8;
typedef volatile uint32_t vu32;
typedef volatile unsigned short vu16;

#define M8(adr) (*((vu8 *)(adr)))
#define M16(adr) (*((vu16 *)(adr)))
#define M32(adr) (*((vu32 *)(adr)))

unsigned char ecc(uint32_t addr, uint32_t data)
{
    unsigned int r = 0;
    r ^= (((addr >> 0) & 0x01010101) * 0xFF) & 0x91C86432;
    r ^= (((addr >> 1) & 0x01010101) * 0xFF) & 0xA1D06834;
    r ^= (((addr >> 2) & 0x01010101) * 0xFF) & 0xC1E07038;
    r ^= (((addr >> 3) & 0x01010101) * 0xFF) & 0x9E4FA7D3;
    r ^= (((addr >> 4) & 0x01010101) * 0xFF) & 0xA251A854;
    r ^= (((addr >> 5) & 0x01010101) * 0xFF) & 0xC261B058;
    r ^= (((addr >> 6) & 0x01010101) * 0xFF) & 0xC4623198;
    r ^= (((addr >> 7) & 0x01010101) * 0xFF) & 0xA4522994;
    r ^= (((data >> 0) & 0x01010101) * 0xFF) & 0x198C4623;
    r ^= (((data >> 1) & 0x01010101) * 0xFF) & 0x1A0D8643;
    r ^= (((data >> 2) & 0x01010101) * 0xFF) & 0x1C0E0783;
    r ^= (((data >> 3) & 0x01010101) * 0xFF) & 0xE9F47A3D;
    r ^= (((data >> 4) & 0x01010101) * 0xFF) & 0x2A158A45;
    r ^= (((data >> 5) & 0x01010101) * 0xFF) & 0x2C160B85;
    r ^= (((data >> 6) & 0x01010101) * 0xFF) & 0x4C261389;
    r ^= (((data >> 7) & 0x01010101) * 0xFF) & 0x4A259249;
    r ^= r >> 16;
    r ^= r >> 8;
    return r & 0xFF;
}

void ProgramDelay(uint32_t value) // 2097151 max
{
    //Init systick
    SysTick->LOAD = value * 8;
    SysTick->CTRL = 0x5; //CLKSOURCE = HCLK,Enable
    SysTick->LOAD = 0;
    while ((SysTick->CTRL & 1 << 16) != 1 << 16)
        ;
    SysTick->CTRL = 0x0; //Disable
}


/*
 *  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */

int ProgramPage(uint32_t adr, uint32_t sz, unsigned char *buf, uint32_t MEMORY)
{
    //	uint32_t *buf_l = (uint32_t *)buf;
    register unsigned int result __asm("r0");
    uint32_t e0, e1;

    sz = (sz + 31) & ~31; // Adjust size

    FLASH1_CNTR->KEY = 0x8555AAA1;

    while (sz) {
        FLASH1_CNTR->CNTR |= 1 << 4;
        FLASH1_CNTR->CNTR |= 1 << 8; //TMR=1
        FLASH1_CNTR->CNTR &= ~(0x3FU << 9); //SE[5:0]=0
        FLASH1_CNTR->CNTR &=
                ~(1 << 20 | 1 << 19 | 1 << 18 | 1 << 17); //NVSTR=0, PROG=0, MAS1=0,ERASE=0
        FLASH1_CNTR->CNTR |= MEMORY << 21; //IFREN=MEMORY

        FLASH1_CNTR->CNTR |= 0x0FU << 26; //SEL[3:0]=1
        //write data
        FLASH1_CNTR->WDATA0 = M32(buf + 0);
        FLASH1_CNTR->WDATA1 = M32(buf + 4);
        FLASH1_CNTR->WDATA2 = M32(buf + 8);
        FLASH1_CNTR->WDATA3 = M32(buf + 12);

        FLASH1_CNTR->ADR = adr >> 4; // 0x01000000+i;

        FLASH1_CNTR->CNTR |= 1 << 15; //XE=1
        FLASH1_CNTR->CNTR |= 1 << 19; //PROG=1
        ProgramDelay(5); /* Wait for 5 us */
        FLASH1_CNTR->CNTR |= 1 << 20; //NVSTR = 1
        ProgramDelay(10); /* Wait for 10 us */
        FLASH1_CNTR->CNTR |= 1 << 16; //YE=1
        ProgramDelay(20); /* Wait for 20 us */
        FLASH1_CNTR->CNTR &= ~(1 << 16); //YE=0
        FLASH1_CNTR->CNTR &= ~(1 << 19); //PROG=0
        ProgramDelay(5); /* Wait for 5 us */
        FLASH1_CNTR->CNTR &= ~(1 << 20); //NVSTR = 0
        FLASH1_CNTR->CNTR &= ~(1 << 15); //XE=0
        ProgramDelay(10); /* Wait for 10 us */

        FLASH1_CNTR->CNTR &= ~(0xFU << 26); //SEL[3:0]=0

        if ((adr & 0x10) == 0x00) {
            e0 = (ecc(adr + 12, M32(buf + 12)) << 24) | (ecc(adr +  8, M32(buf +  8)) << 16) |
                 (ecc(adr +  4, M32(buf +  4)) <<  8) | (ecc(adr +  0, M32(buf +  0)) <<  0);
            e1 = (ecc(adr + 28, M32(buf + 28)) << 24) | (ecc(adr + 24, M32(buf + 24)) << 16) |
                 (ecc(adr + 20, M32(buf + 20)) <<  8) | (ecc(adr + 16, M32(buf + 16)) <<  0);

            //write ecc
            FLASH1_CNTR->CNTR |= 0x30U << 26; //SEL[5:4]=1

            FLASH1_CNTR->ADR = adr >> 5;

            FLASH1_CNTR->WECC0 = e0;
            FLASH1_CNTR->WECC1 = e1;

            FLASH1_CNTR->CNTR |= 1 << 15; //XE=1
            FLASH1_CNTR->CNTR |= 1 << 19; //PROG=1
            ProgramDelay(5); /* Wait for 5 us */
            FLASH1_CNTR->CNTR |= 1 << 20; //NVSTR = 1
            ProgramDelay(10); /* Wait for 10 us */
            FLASH1_CNTR->CNTR |= 1 << 16; //YE=1
            ProgramDelay(20); /* Wait for 20 us */
            FLASH1_CNTR->CNTR &= ~(1 << 16); //YE=0
            FLASH1_CNTR->CNTR &= ~(1 << 19); //PROG=0
            ProgramDelay(5); /* Wait for 5 us */
            FLASH1_CNTR->CNTR &= ~(1 << 20); //NVSTR = 0
            FLASH1_CNTR->CNTR &= ~(1 << 15); //XE=0
            ProgramDelay(10); /* Wait for 10 us */

            FLASH1_CNTR->CNTR &= ~(0x30U << 26); //SEL[5:4]=0

            FLASH1_CNTR->CNTR &= ~(1 << 21); //IFREN=0
            FLASH1_CNTR->CNTR &= ~(1 << 8); //TMR=0
            FLASH1_CNTR->CNTR &= ~(1 << 4);
        }
        // Go to next
        adr += 16;
        buf += 16;
        sz -= 16;
    }

    FLASH1_CNTR->CNTR &= ~(0x30U << 26); //SEL[5:4]=0

    FLASH1_CNTR->CNTR &= ~(1 << 21); //IFREN=0
    FLASH1_CNTR->CNTR &= ~(1 << 8); //TMR=0
    FLASH1_CNTR->CNTR &= ~(1 << 4);

    FLASH1_CNTR->KEY = 0x00000000;

    result = 0;

    __ASM volatile("BKPT #00"); //	bkpt	#0

    return (result); // Done
}


#if 0
uint32_t Verify(uint32_t adr, uint32_t sz, unsigned char *buf, uint32_t MEMORY) {
//	uint32_t *buf_l = (uint32_t *)buf;
	volatile uint32_t e0, e1;
	register unsigned int result __asm("r0");
	signed long s = sz;																	

	FLASH1_CNTR->KEY  = 0x8555AAA1;
																		
  result = adr + s; // Success
	
  FLASH1_CNTR->CNTR |= 1<<4;
  FLASH1_CNTR->CNTR |= 1<<8;//TMR=1
  FLASH1_CNTR->CNTR &= ~(1<<20 | 1<<19 | 1<<18 | 1<<17); //NVSTR=0, PROG=0, MAS1=0,ERASE=0
  FLASH1_CNTR->CNTR |= MEMORY<<21 | 1<<16 | 1<<15;//IFREN=MEMORY,YE=1,XE=1
  FLASH1_CNTR->CNTR |= 0x3FU<<26;//SEL[5:0]=1
																		
	while (s>0) {

    FLASH1_CNTR->ADR = (adr>>4);
    FLASH1_CNTR->CNTR |= 0x0FU<<9;//SE[3:0]=1 // 0xF
    FLASH1_CNTR->CNTR |= 1<<22;//rdata_ready=1
    FLASH1_CNTR->CNTR &= ~(1<<22);//rdata_ready=0
    FLASH1_CNTR->CNTR &= ~(0x0FU<<9);//SE[3:0]=0 // 0xF

		if ((s> 0) && (FLASH1_CNTR->RDATA0 != M32(buf+ 0)))
		  {result = adr+ 0; break;}
		if ((s> 4) && (FLASH1_CNTR->RDATA1 != M32(buf+ 4)))
		  {result = adr+ 4; break;}
		if ((s> 8) && (FLASH1_CNTR->RDATA2 != M32(buf+ 8)))
		  {result = adr+ 8; break;}
		if ((s>12) && (FLASH1_CNTR->RDATA3 != M32(buf+12)))
		  {result = adr+12; break;}

			
		if ((adr&0x10)==0x00)
		{
			e0 = (ecc(adr+12, M32(buf+12))<<24) | (ecc(adr+ 8, M32(buf+ 8))<<16) | (ecc(adr+ 4, M32(buf+ 4))<<8) | (ecc(adr+ 0, M32(buf+ 0))<<0);
			e1 = (ecc(adr+28, M32(buf+28))<<24) | (ecc(adr+24, M32(buf+24))<<16) | (ecc(adr+20, M32(buf+20))<<8) | (ecc(adr+16, M32(buf+16))<<0);	
			
			FLASH1_CNTR->ADR = adr>>5;
			FLASH1_CNTR->CNTR |= (0x30U<<9);//SE4L[5:4]=1
			FLASH1_CNTR->CNTR |= (1<<22);//rdata_ready=1
			FLASH1_CNTR->CNTR &=~(1<<22);//rdata_ready=0
			FLASH1_CNTR->CNTR &=~(0x30U<<9);//SE4L[5:4]=0
			
  		if ((s> 12+ 0) && (FLASH1_CNTR->RECC0 != e0))
	  	  {result = adr+ 0; break;}
  		if ((s> 12+16) && (FLASH1_CNTR->RECC1 != e1))
	  	  {result = adr+16; break;}
		}			
			
		// Go to next 
		adr += 16;
		buf += 16;
		s  -= 16;
	}
	
  FLASH1_CNTR->CNTR &= ~(0x3FU<<26);//SEL[5:4]=0
  FLASH1_CNTR->CNTR &=~(1<<21 | 1<<16 | 1<<15);//IFREN=0,YE=0,XE=0
  FLASH1_CNTR->CNTR &= ~(1<<8);//TMR=0    
  FLASH1_CNTR->CNTR &= ~(1<<4);		

	FLASH1_CNTR->KEY  = 0x00000000;

	__ASM volatile("BKPT #00");	//	bkpt	#0

  return (result);                                   // Done
}
#endif

const uint32_t rCrc32Tab[] __attribute__((aligned(8))) = {
    0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA, 0x076DC419, 0x706AF48F, 0xE963A535, 0x9E6495A3,
    0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988, 0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91,
    0x1DB71064, 0x6AB020F2, 0xF3B97148, 0x84BE41DE, 0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7,
    0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC, 0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5,
    0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172, 0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B,
    0x35B5A8FA, 0x42B2986C, 0xDBBBC9D6, 0xACBCF940, 0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59,
    0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116, 0x21B4F4B5, 0x56B3C423, 0xCFBA9599, 0xB8BDA50F,
    0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924, 0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D,
    0x76DC4190, 0x01DB7106, 0x98D220BC, 0xEFD5102A, 0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433,
    0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818, 0x7F6A0DBB, 0x086D3D2D, 0x91646C97, 0xE6635C01,
    0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E, 0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457,
    0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA, 0xFCB9887C, 0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65,
    0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2, 0x4ADFA541, 0x3DD895D7, 0xA4D1C46D, 0xD3D6F4FB,
    0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0, 0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9,
    0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086, 0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F,
    0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4, 0x59B33D17, 0x2EB40D81, 0xB7BD5C3B, 0xC0BA6CAD,
    0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A, 0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683,
    0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8, 0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,
    0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE, 0xF762575D, 0x806567CB, 0x196C3671, 0x6E6B06E7,
    0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC, 0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5,
    0xD6D6A3E8, 0xA1D1937E, 0x38D8C2C4, 0x4FDFF252, 0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B,
    0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60, 0xDF60EFC3, 0xA867DF55, 0x316E8EEF, 0x4669BE79,
    0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236, 0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F,
    0xC5BA3BBE, 0xB2BD0B28, 0x2BB45A92, 0x5CB36A04, 0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D,
    0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A, 0x9C0906A9, 0xEB0E363F, 0x72076785, 0x05005713,
    0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38, 0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21,
    0x86D3D2D4, 0xF1D4E242, 0x68DDB3F8, 0x1FDA836E, 0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777,
    0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C, 0x8F659EFF, 0xF862AE69, 0x616BFFD3, 0x166CCF45,
    0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2, 0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB,
    0xAED16A4A, 0xD9D65ADC, 0x40DF0B66, 0x37D83BF0, 0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9,
    0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6, 0xBAD03605, 0xCDD70693, 0x54DE5729, 0x23D967BF,
    0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94, 0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D
};

__forceinline uint32_t crc32_32r(uint32_t crc, uint32_t val)
{
    crc = (crc >> 8) ^ rCrc32Tab[(crc & 0xff)] ^ ((val >> 0) << 24);
    crc = (crc >> 8) ^ rCrc32Tab[(crc & 0xff)] ^ ((val >> 8) << 24);
    crc = (crc >> 8) ^ rCrc32Tab[(crc & 0xff)] ^ ((val >> 16) << 24);
    crc = (crc >> 8) ^ rCrc32Tab[(crc & 0xff)] ^ ((val >> 24) << 24);
    return crc;
}

__forceinline unsigned int reverse(unsigned int x)
{
    x = (((x & 0xaaaaaaaa) >> 1) | ((x & 0x55555555) << 1));
    x = (((x & 0xcccccccc) >> 2) | ((x & 0x33333333) << 2));
    x = (((x & 0xf0f0f0f0) >> 4) | ((x & 0x0f0f0f0f) << 4));
    x = (((x & 0xff00ff00) >> 8) | ((x & 0x00ff00ff) << 8));
    return ((x >> 16) | (x << 16));
}

#ifdef DEBUG
uint32_t ReadWord(uint32_t MEMORY, uint32_t adr)
{
	  uint32_t data;
	
    FLASH1_CNTR->CNTR |= 1 << 4; // MODE
    FLASH1_CNTR->CNTR |= 1 << 8; //TMR=1
    FLASH1_CNTR->CNTR &= ~(0x3FU << 9); //SE[5:0]=0
    FLASH1_CNTR->CNTR &= ~(1 << 20 | 1 << 19 | 1 << 18 | 1 << 17 |
                           1 << 21); //NVSTR=0, PROG=0, MAS1=0,ERASE=0,IFREN=0
    FLASH1_CNTR->CNTR &= ~(1 << 16 | 1 << 15); //YE=0,XE=0
    FLASH1_CNTR->CNTR &= ~(0x3FU << 26); //SEL[5:0]=0
    FLASH1_CNTR->CNTR |= MEMORY << 21; //IFREN=MEMORY
    FLASH1_CNTR->CNTR |= 0x0FU << 26; //SEL[3:0]=1

    FLASH1_CNTR->ADR = adr >> 4;

    // read data
    FLASH1_CNTR->CNTR |= 1 << 16 | 1 << 15; //YE=1,XE=1
    FLASH1_CNTR->CNTR |= 0x0FU << 9; //SE[3:0]=1 // 0xF
    FLASH1_CNTR->CNTR |= 1 << 22; //rdata_ready=1
    FLASH1_CNTR->CNTR &= ~(0x0FU << 9); //SE[3:0]=0 // 0xF
    FLASH1_CNTR->CNTR &= ~(1 << 16 | 1 << 15); //YE=0,XE=0

		data = ((adr >> 2) & 3) == 0 ? FLASH1_CNTR->RDATA0 :
					 ((adr >> 2) & 3) == 1 ? FLASH1_CNTR->RDATA1 : 
					 ((adr >> 2) & 3) == 2 ? FLASH1_CNTR->RDATA2 : 
					                         FLASH1_CNTR->RDATA3; 

    FLASH1_CNTR->CNTR &= ~(0x3FU << 26); //SEL[5:0]=0

    FLASH1_CNTR->CNTR &= ~(1 << 21); //IFREN=0
    FLASH1_CNTR->CNTR &= ~(1 << 8); //TMR=0
    FLASH1_CNTR->CNTR &= ~(1 << 4);

    return (data); 
}
#endif

int ProgramWord(uint32_t MEMORY, uint32_t adr, uint32_t data)
{
    FLASH1_CNTR->CNTR |= 1 << 4; // MODE
    FLASH1_CNTR->CNTR |= 1 << 8; //TMR=1
    FLASH1_CNTR->CNTR &= ~(0x3FU << 9); //SE[5:0]=0
    FLASH1_CNTR->CNTR &= ~(1 << 20 | 1 << 19 | 1 << 18 | 1 << 17 |
                           1 << 21); //NVSTR=0, PROG=0, MAS1=0,ERASE=0,IFREN=0
    FLASH1_CNTR->CNTR &= ~(1 << 16 | 1 << 15); //YE=0,XE=0
    FLASH1_CNTR->CNTR &= ~(0x3FU << 26); //SEL[5:0]=0
    FLASH1_CNTR->CNTR |= MEMORY << 21; //IFREN=MEMORY
    FLASH1_CNTR->CNTR |= 0x0FU << 26; //SEL[3:0]=1

    FLASH1_CNTR->ADR = adr >> 4;

    // read data
    FLASH1_CNTR->CNTR |= 1 << 16 | 1 << 15; //YE=1,XE=1
    FLASH1_CNTR->CNTR |= 0x0FU << 9; //SE[3:0]=1 // 0xF
    FLASH1_CNTR->CNTR |= 1 << 22; //rdata_ready=1
    FLASH1_CNTR->CNTR &= ~(0x0FU << 9); //SE[3:0]=0 // 0xF
    FLASH1_CNTR->CNTR &= ~(1 << 16 | 1 << 15); //YE=0,XE=0

    //write data
    FLASH1_CNTR->WDATA0 = ((adr >> 2) & 3) == 0 ? data : FLASH1_CNTR->RDATA0;
    FLASH1_CNTR->WDATA1 = ((adr >> 2) & 3) == 1 ? data : FLASH1_CNTR->RDATA1;
    FLASH1_CNTR->WDATA2 = ((adr >> 2) & 3) == 2 ? data : FLASH1_CNTR->RDATA2;
    FLASH1_CNTR->WDATA3 = ((adr >> 2) & 3) == 3 ? data : FLASH1_CNTR->RDATA3;

    FLASH1_CNTR->CNTR |= 1 << 15; //XE=1
    FLASH1_CNTR->CNTR |= 1 << 19; //PROG=1
    ProgramDelay(5); /* Wait for 5 us */
    FLASH1_CNTR->CNTR |= 1 << 20; //NVSTR = 1
    ProgramDelay(10); /* Wait for 10 us */
    FLASH1_CNTR->CNTR |= 1 << 16; //YE=1
    ProgramDelay(20); /* Wait for 20 us */
    FLASH1_CNTR->CNTR &= ~(1 << 16); //YE=0
    FLASH1_CNTR->CNTR &= ~(1 << 19); //PROG=0
    ProgramDelay(5); /* Wait for 5 us */
    FLASH1_CNTR->CNTR &= ~(1 << 20); //NVSTR = 0
    FLASH1_CNTR->CNTR &= ~(1 << 15); //XE=0
    ProgramDelay(10); /* Wait for 10 us */

    FLASH1_CNTR->CNTR &= ~(0x3FU << 26); //SEL[5:0]=0

    FLASH1_CNTR->CNTR &= ~(1 << 21); //IFREN=0
    FLASH1_CNTR->CNTR &= ~(1 << 8); //TMR=0
    FLASH1_CNTR->CNTR &= ~(1 << 4);

    return (0); // Done
}

uint32_t FlashLock(uint32_t key1_addr, uint32_t key2_addr, uint32_t crc_addr, uint32_t key1, uint32_t key2)
{
    register unsigned int result __asm("r0");
    uint32_t adr;
    uint32_t sz;
    uint32_t crc;

    //uint32_t key1_addr = 0x010fffd0;
    //uint32_t key2_addr = 0x010fffe0;
    //uint32_t crc_addr = 0x010ffff0;
    //uint32_t key1 = key & 0xFFFF0000; //0x12340000;
    //uint32_t key2 = key & 0x0000FFFF; //0x00005678;

    FLASH1_CNTR->KEY = 0x8555AAA1;

    ProgramWord(1, 0x1C, key1_addr);
    ProgramWord(1, 0x2C, key2_addr);
    ProgramWord(1, 0x3C, crc_addr);
    ProgramWord(0, key1_addr, key1);
    ProgramWord(0, key2_addr, key2);
#ifdef DEBUG
		ReadWord(1, 0x1C);
		ReadWord(1, 0x2C);
		ReadWord(1, 0x3C);
		ReadWord(0, key1_addr);
		ReadWord(0, key2_addr);
#endif

		adr = 0x01000000;
		sz = 0x00100000;
    crc = 0xFFFFFFFF;

    FLASH1_CNTR->CNTR |= 1 << 4;
    FLASH1_CNTR->CNTR |= 1 << 8; //TMR=1
    FLASH1_CNTR->CNTR &= ~(0x3FU << 9); //SE[5:0]=0
    FLASH1_CNTR->CNTR &= ~(1 << 20 | 1 << 19 | 1 << 18 | 1 << 17 |
                           1 << 21); //NVSTR=0, PROG=0, MAS1=0,ERASE=0,IFREN=0
    FLASH1_CNTR->CNTR |= 1 << 16 | 1 << 15; //YE=1,XE=1
    FLASH1_CNTR->CNTR |= 0x3FU << 26; //SEL[5:0]=1

    while (sz) {
        FLASH1_CNTR->ADR = adr >> 4;
        FLASH1_CNTR->CNTR |= 0x0FU << 9; //SE[3:0]=1 // 0xF
        FLASH1_CNTR->CNTR |= 1 << 22; //rdata_ready=1
        //    FLASH1_CNTR->CNTR &= ~(1<<22);//rdata_ready=0
        FLASH1_CNTR->CNTR &= ~(0x0FU << 9); //SE[3:0]=0 // 0xF

        //		if (adr==0x010fffd0)
        //			__NOP();
        if (adr != crc_addr) {
#ifndef MLDR149
            if (adr >= 0x010e0000) {
                /*
			if      (adr == key1_addr)
				crc = crc32_32r(crc, 0); 
			else if (adr == key2_addr)
				crc = crc32_32r(crc, 0); 
			else
				crc = crc32_32r(crc, 0); 
			*/
                crc = crc32_32r(crc, 0);
                crc = crc32_32r(crc, 0);
            } else
#endif
            {
                crc = crc32_32r(crc, FLASH1_CNTR->RDATA0);
                crc = crc32_32r(crc, FLASH1_CNTR->RDATA1);
            }
            crc = crc32_32r(crc, FLASH1_CNTR->RDATA2);
            crc = crc32_32r(crc, FLASH1_CNTR->RDATA3);
            //MSG_1(("%08X %08X\n", crc, reverse(crc)));
        }
        // Go to next
        adr += 16;
        sz -= 16;
    }

    FLASH1_CNTR->CNTR &= ~(0x3FU << 26); //SEL[5:4]=0
    FLASH1_CNTR->CNTR &= ~(1 << 16 | 1 << 15); //YE=0,XE=0
    FLASH1_CNTR->CNTR &= ~(1 << 8); //TMR=0
    FLASH1_CNTR->CNTR &= ~(1 << 4);
    crc = reverse(crc);

    ProgramWord(0, crc_addr, crc);
#if 1
		FLASH1_CNTR->WDATA0 = key2;
#endif		
    FLASH1_CNTR->KEY = 0x00000000;

    result = crc;
    __ASM volatile("BKPT #00"); //	bkpt	#0

    return (result);
}
/*
; Linker Control File (scatter-loading)
;

PRG 0x20000000 PI               ; Programming Functions
{
  PrgCode +0           ; Code
  {
    * (+RO)
  }
  PrgData +0           ; Data
  {
    * (+RW,+ZI)
  }
}


load FLM1.hex; 
RESET; _WDWORD(0x40006000, 0x8555AAA1); _WDWORD(0x40006004, 0x83); PC=FlashLock; R0=0x010fffd0; R1=0x010fffe0; R2=0x010ffff0; R3=0x12340000; _WDWORD(SP-4, 0x00005678); SP=SP-4
//R4=0x00005678; 
RESET; _WDWORD(0x40006000, 0x8555AAA1); _WDWORD(0x4000604C, 0xB3C3B3C3); _WDWORD(0x40006004, 0x23); _RDWORD(0x40006004);


*/
