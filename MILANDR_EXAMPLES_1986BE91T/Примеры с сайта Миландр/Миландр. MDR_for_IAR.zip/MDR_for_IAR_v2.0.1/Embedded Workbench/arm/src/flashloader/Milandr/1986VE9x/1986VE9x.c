/**************************************************
* Copyright 2004-2010 IAR Systems. All rights reserved.
*
* $Revision: 34539 $
**************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "flash_loader.h"

#include "MDR32Fx.h"
#include "MDR32F9Qx_eeprom.h"

static __no_init uint32_t bankSelect;

#if USE_ARGC_ARGV
uint32_t FlashInit(void *base_of_flash, uint32_t image_size,
                   uint32_t link_address, uint32_t flags,
                   int argc, char const *argv[])
#else
uint32_t FlashInit(void *base_of_flash, uint32_t image_size,
                   uint32_t link_address, uint32_t flags)
#endif
{
    MDR_RST_CLK->PER_CLOCK = 0x00000018;                                                 // RST_CLK_EN | EEPROM_CNTRL_EN

    bankSelect = EEPROM_Main_Bank_Select;
#if USE_ARGC_ARGV
    for(int i = 0; i < argc; i++)
    {
        if(strcmp("--info_page", argv[i]) == 0)
        {
            bankSelect = EEPROM_Info_Bank_Select;
        }
    }
#endif    
    
    if(flags & FLAG_ERASE_ONLY)
    {
        if(bankSelect == EEPROM_Info_Bank_Select)
            EEPROM_ErasePage( 0x00000000, bankSelect );
        else
          EEPROM_EraseAllPages( bankSelect );
        return RESULT_ERASE_DONE;
    }
    
    return RESULT_OK;
}

uint32_t FlashWrite(void *block_start,
                    uint32_t offset_into_block,
                    uint32_t count,
                    char const *buffer)
{
    uint32_t size = 0;
    
    while( size < count )
    {
        EEPROM_ProgramWord( ( uint32_t )block_start + offset_into_block + size,
                            bankSelect,
                           *((uint32_t *)buffer) );
        buffer += 4;
        size += 4;
    }
  
    return(RESULT_OK);
}

uint32_t FlashErase(void *block_start,
                    uint32_t block_size)
{
    EEPROM_ErasePage( ( uint32_t )block_start, bankSelect );
    
    return(RESULT_OK);
}

OPTIONAL_CHECKSUM
uint32_t FlashChecksum(void const *begin, uint32_t count)
{
    Crc16((uint8_t const *)begin, 64);                                                  // This fix error                                      
    return Crc16((uint8_t const *)begin, count);
}

OPTIONAL_SIGNOFF
uint32_t FlashSignoff()
{
    MDR_RST_CLK->PER_CLOCK = 0x00000010;                                                // RST_CLK_EN
    return RESULT_OK;
}
