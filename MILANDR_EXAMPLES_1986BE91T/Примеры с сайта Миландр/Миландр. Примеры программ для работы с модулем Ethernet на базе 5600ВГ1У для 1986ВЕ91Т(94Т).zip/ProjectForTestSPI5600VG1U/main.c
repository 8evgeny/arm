/*
Автор: Дьячков Петр
Дата:  27.05.2021
Версия:	1.11

Программа, реализующая ICMP-протокол на микроконтроллере 1986ВЕ91Т и микросхеме 5600ВГ1У.
Используется последовательный порт (SPI), частота: 7,5 МГц. Учтён обход ошибки errata 0001.

1986ВЕ91Т: Частота тактирования микроконтроллера: 80 МГц (включена PLL с коэффициентом умножения 9).

Конфигурация 5600ВГ1У:	MAC-адрес: 0A.1B.2C.3D.4E.5F
          				Прием широковещательных пакетов и с полным совпадением MAC-адреса

          				IP-адрес: 192.168.1.87
          				контроллер по ICMP-протоколу может принимать до 1450 байт в одном пакете
*/


#define MAIN_PROGRAMM 1		//включение для компилляции основной программы
#define READSTATUSON  1	 	//включение наблюдения за регистрами конфигурации и статусными регистрами

#define NUMRXDESC	10		//max value = 32, max value of use Rx descriptors (количество используемых дескрипторов приема)
#define	NUMTXDESC	10		//max value = 32, max value of use Tx descriptors (количество используемых дескрипторов передачи)

//***************************************************************************************************
//***************************************************************************************************
//***************************************************************************************************
//структура дескриптора приемника/передатчика
typedef struct
{
	unsigned short StartAddress;		 //начальный адрес дескриптора
	unsigned short PacketLength;		 //длина пакета в байтах
	unsigned short PacketStartAddressH;	 //старшая часть адреса, где расположен пакет в буфере (всегда 0)
	unsigned short PacketStartAddressL;	 //младшая часть адреса, где расположен пакет в буфере
	unsigned short LastDesc;			 //последний дескриптор (0 - не последний, 1 - последний)
} __descriptor;

//структура, для организации работы с дескрипторами приемника; указывает на текущий дескриптор приемника
typedef struct
{
	__descriptor* RxCurrentDescriptor;	 //указатель на текущий дескриптор приемника (обрабатываемого в настоящий момент)
	unsigned short Number;				 //номер текущего дескриптора приемника (обрабатываемого в настоящий момент)
} _rx_current_descriptor;

//структура, для организации работы с дескрипторами передатчика; указывает на текущий дескриптор передатчика
typedef struct
{
	__descriptor* TxCurrentDescriptor;	 //указатель на текущий дескриптор передатчика (обрабатываемого в настоящий момент)
	unsigned short Number;				 //номер текущего дескриптора передатчика (обрабатываемого в настоящий момент)
	unsigned short FirstEmptyByte;		 //адрес первого свободного байта в буфере передатчика
} _tx_current_descriptor;

void InitTxDescriptor(_tx_current_descriptor*);	//функция инициализации дескрипторов передатчика
void InitRxDescriptor(_rx_current_descriptor*);	//функция инициализации дескрипторов приемника

//дескрипторы передатчика
__descriptor	TxDescriptor[32] = {{0x1800,0,0,0,0},{0x1804,0,0,0,0},{0x1808,0,0,0,0},{0x180C,0,0,0,0},
									{0x1810,0,0,0,0},{0x1814,0,0,0,0},{0x1818,0,0,0,0},{0x181C,0,0,0,0},
									{0x1820,0,0,0,0},{0x1824,0,0,0,0},{0x1828,0,0,0,0},{0x182C,0,0,0,0},
									{0x1830,0,0,0,0},{0x1834,0,0,0,0},{0x1838,0,0,0,0},{0x183C,0,0,0,0},
									{0x1840,0,0,0,0},{0x1844,0,0,0,0},{0x1848,0,0,0,0},{0x184C,0,0,0,0},
									{0x1850,0,0,0,0},{0x1854,0,0,0,0},{0x1858,0,0,0,0},{0x185C,0,0,0,0},
									{0x1860,0,0,0,0},{0x1864,0,0,0,0},{0x1868,0,0,0,0},{0x186C,0,0,0,0},
									{0x1870,0,0,0,0},{0x1874,0,0,0,0},{0x1878,0,0,0,0},{0x187C,0,0,0,1}};

//дескрипторы приемника
__descriptor	RxDescriptor[32] = {{0x0800,0,0,0,0},{0x0804,0,0,0,0},{0x0808,0,0,0,0},{0x080C,0,0,0,0},
									{0x0810,0,0,0,0},{0x0814,0,0,0,0},{0x0818,0,0,0,0},{0x081C,0,0,0,0},
									{0x0820,0,0,0,0},{0x0824,0,0,0,0},{0x0828,0,0,0,0},{0x082C,0,0,0,0},
									{0x0830,0,0,0,0},{0x0834,0,0,0,0},{0x0838,0,0,0,0},{0x083C,0,0,0,0},
									{0x0840,0,0,0,0},{0x0844,0,0,0,0},{0x0848,0,0,0,0},{0x084C,0,0,0,0},
									{0x0850,0,0,0,0},{0x0854,0,0,0,0},{0x0858,0,0,0,0},{0x085C,0,0,0,0},
									{0x0860,0,0,0,0},{0x0864,0,0,0,0},{0x0868,0,0,0,0},{0x086C,0,0,0,0},
									{0x0870,0,0,0,0},{0x0874,0,0,0,0},{0x0878,0,0,0,0},{0x087C,0,0,0,1}};

_tx_current_descriptor TxCurrentDesc;	//структура, указывающая на текущий дескриптор передатчика
_rx_current_descriptor RxCurrentDesc;	//структура, указывающая на текущий дескриптор приемника

//***************************************************************************************************
//***************************************************************************************************
//***************************************************************************************************

#include "config.h"

#if	READSTATUSON
typedef struct
{
	unsigned short MAC_CTRL;
	unsigned short MinFrame;
	unsigned short MaxFrame;
	unsigned short CollConfig;
	unsigned short IPGTx;
	unsigned short MAC_ADDR_T;
	unsigned short MAC_ADDR_M;
	unsigned short MAC_ADDR_H;
	unsigned short HASH0;
	unsigned short HASH1;
	unsigned short HASH2;
	unsigned short HASH3;
	unsigned short INT_MSK;
	unsigned short INT_SRC;
	unsigned short PHY_CTRL;
	unsigned short PHY_STAT;
	unsigned short RXBF_HEAD;
	unsigned short RXBF_TAIL;
	unsigned short STAT_RX_ALL;
	unsigned short STAT_RX_OK;
	unsigned short STAT_RX_OVF;
	unsigned short STAT_RX_LOST;
	unsigned short STAT_TX_ALL;
	unsigned short STAT_TX_OK;
	unsigned short GCTRL;
} _5600_registr;
#endif //READSTATUSON


//структура принятого пакета
typedef struct
{
        unsigned char Data[1600];       //Data in packet
        unsigned short Length;          //Length of receive Data
        unsigned short Address;         //Start address of paket in buffer 5600VG1U
        unsigned char Remote_IP[4];     //IP-address remote host
        unsigned char Remote_MAC[6];    //MAC-address remote host

//статусные регистры
#if	READSTATUSON
		unsigned int CounterTxPacket;	//счетчик всех отправленных пакетов
		unsigned int CounterRxPacket;	//счетчик всех принятых пакетов
		_5600_registr Registr;
#endif //READSTATUSON

} _ethernet_packet;
						   
int Read_Packet(_ethernet_packet*);					 //функция для считывания полученного пакета
void Request_Status(_ethernet_packet*);				 //функция для считывания статусных регистров контроллера

unsigned short CheckSum_IP(_ethernet_packet*);		 //функция для подсчета контрольной суммы IP-пакета
unsigned short CheckSum_ICMP(_ethernet_packet*);	 //функция для подсчета контрольной суммы ICMP-пакета
int Answear_ARP(_ethernet_packet*);					//функция для формирования ответа на ARP-запрос (ARP - Address Resolution Protocol)
int Answear_ICMP(_ethernet_packet*,unsigned char*); //функция для формирования ответа на ICMP-пакет (ICMP - Internet Control Messager Protocol)
void Packet_Handler(void);                          //функция обработки принятых пакетов
void Disable_RX_MAC(void);                          //функция, выполняющая сброс ПРМ MAC-контроллера
void Enable_RX_MAC(void);                           //функция, выполняющая инициализацию и разрешение работы ПРМ MAC-контроллера
void ReInitRxDescriptor(void);                      //функция для переинициализации дескрипторов принимаемых пакетов после сброса ПРМ MAC-контроллера
__inline void InitStatusRegistr(_ethernet_packet* Packet);
__inline void InitEthPacket(_ethernet_packet* Packet);				   

_ethernet_packet Packet;				//в эту структуру копируется принятый пакет

unsigned short Temp, TypeOfProtocol;	//Temp - временная переменная, TypeOfProtocol - тип протокола принятого пакета (6-е слово в пакете)
unsigned char My_IP[4], My_MAC[6];		//ip-адрес нашего устройства, MAC-адрес нашего устройства
unsigned char Receive_IP[4];			//ip-адрес принятого пакета
unsigned char ICMP_Packet[1500]; 	 	//буфер для формирования ответного ICMP-пакета
unsigned short Int_Src;	                //переменная для хранения значения регистра флагов прерываний INT_SRC

//***************************************************************************************************
//***************************************************************************************************
//***************************************************************************************************

int main()
{
        ClkCfg();
        PortConfig();
        SPIConfig();
		
		EthCfg();

        My_IP[0] =  0xC0;
        My_IP[1] =  0xA8;
        My_IP[2] =  0x01;
        My_IP[3] =  0x57;

        My_MAC[0] = 0x0A;
        My_MAC[1] = 0x1B;
        My_MAC[2] = 0x2C;
        My_MAC[3] = 0x3D;
        My_MAC[4] = 0x4E;
        My_MAC[5] = 0x5F;
        
		InitRxDescriptor(&RxCurrentDesc);
		InitTxDescriptor(&TxCurrentDesc);

        PORTD->RXTX = 1 << 12;
        PORTD->RXTX = 1 << 10;

		InitEthPacket(&Packet);
//микросхема 5600ВГ1У сконфигурирована и готова к приему пакетов
        while(1)
        {
#if READSTATUSON
				Request_Status(&Packet);
#endif	//READSTATUSON
            
                Int_Src = Read_Word(REG_INT_SRC); // Чтение INT_SRC
        
                if(Int_Src & (1<<14)) // INT_SRC.RXE - произошла ошибка при приёме пакета
                {
                        Write_Word( (1<<14), REG_INT_SRC);     // Сброс INT_SRC.RXE
                        Disable_RX_MAC();
                
                        if(Int_Src & (1<<15))             // INT_SCR.RXF - наличие успешно принятого пакета
                        {
                                Write_Word( (1<<15), REG_INT_SRC); // Сброс INT_SRC.RXF
                                Packet_Handler();
                        }
                        Enable_RX_MAC();
                }
                else if(Int_Src & (1<<15)) // INT_SRC.RXF  - наличие успешно принятого пакета
                {
                        Write_Word( (1<<15), REG_INT_SRC); // Сброс INT_SRC.RXF
                        Packet_Handler();
                }      
        }	
}

//***************************************************************************************************
//***************************************************************************************************
//Функция обработки принятых пакетов
//Параметр:	нет
//Возвращаемых значений нет
//***************************************************************************************************
void Packet_Handler(void)
{
        while(Read_Rx_Descriptor(RxCurrentDesc.RxCurrentDescriptor) == 0) //we receive Eth. packet
        {
                PORTD->RXTX |= 1 << 11;

                Packet.Length = Read_Packet_Length(RxCurrentDesc.RxCurrentDescriptor);
                Packet.Address = Read_Packet_Start_Address(RxCurrentDesc.RxCurrentDescriptor);
                Read_Packet(&Packet);   //считали пакет, который только что получили.

                Ready_Rx_Descriptor(RxCurrentDesc.RxCurrentDescriptor);
#if READSTATUSON
                Packet.CounterRxPacket++;
#endif	//READSTATUSON
                      
                Write_Word( (((Read_Word(REG_RXBF_HEAD)*sizeof(short) + Packet.Length +1) & 0x07FF)/sizeof(short)), REG_RXBF_HEAD);

                TypeOfProtocol = (Packet.Data[12]<<8)|Packet.Data[13];

                switch(TypeOfProtocol) //0x0006 //слова в памяти разбиты по 2 байта! (считывать массив кратный 2 байтам!)
                {
                        case 0x0608:    //receive ARP-packet
                                Receive_IP[0] = Packet.Data[39];
                                Receive_IP[1] = Packet.Data[38];
                                Receive_IP[2] = Packet.Data[41];
                                Receive_IP[3] = Packet.Data[40];

                                if( (Receive_IP[0] == My_IP[0])&&(Receive_IP[1] == My_IP[1])&&(Receive_IP[2] == My_IP[2])&&(Receive_IP[3] == My_IP[3]))         //полное совпадение IP в пакете и моего. Надо отвечать
                                {
                                                Packet.Remote_IP[0] = Packet.Data[28];
                                                Packet.Remote_IP[1] = Packet.Data[29];
                                                Packet.Remote_IP[2] = Packet.Data[30];
                                                Packet.Remote_IP[3] = Packet.Data[31];

                                                Packet.Remote_MAC[0] = Packet.Data[22];
                                                Packet.Remote_MAC[1] = Packet.Data[23];
                                                Packet.Remote_MAC[2] = Packet.Data[24];
                                                Packet.Remote_MAC[3] = Packet.Data[25];
                                                Packet.Remote_MAC[4] = Packet.Data[26];
                                                Packet.Remote_MAC[5] = Packet.Data[27];

                                                Answear_ARP(&Packet);

                                                PORTD->RXTX &= 0xF7FF;
                                }
                                else
                                {
                                        PORTD->RXTX &= 0xF7FF;
                                }
                                break;

                        case 0x0008:    //receive IP-packet
                                Receive_IP[0] = Packet.Data[31];
                                Receive_IP[1] = Packet.Data[30];
                                Receive_IP[2] = Packet.Data[33];
                                Receive_IP[3] = Packet.Data[32];

                                if((Receive_IP[0] == My_IP[0])&&(Receive_IP[1] == My_IP[1])&&(Receive_IP[2] == My_IP[2])&&(Receive_IP[3] == My_IP[3]))  //получили IP-пакет с нашим IP адресом
                                {
                                                Temp = CheckSum_IP(&Packet);
                                                if(Temp == ((Packet.Data[24] << 8)&0xFF00|Packet.Data[25]))  //если контрольная сумма IP-пакета и вычисленная совпадают, то анализируем пакет дальше, иначе отбрасываем его
                                                {
                                                        Packet.Remote_IP[0] = Packet.Data[26];
                                                        Packet.Remote_IP[1] = Packet.Data[27];
                                                        Packet.Remote_IP[2] = Packet.Data[28];
                                                        Packet.Remote_IP[3] = Packet.Data[29];

                                                        Packet.Remote_MAC[0] = Packet.Data[6];
                                                        Packet.Remote_MAC[1] = Packet.Data[7];
                                                        Packet.Remote_MAC[2] = Packet.Data[8];
                                                        Packet.Remote_MAC[3] = Packet.Data[9];
                                                        Packet.Remote_MAC[4] = Packet.Data[10];
                                                        Packet.Remote_MAC[5] = Packet.Data[11];

                                                        //проверяем следующий протокол (ICMP)
                                                        if(Packet.Data[22] == 0x01)     //далее следует ICMP-протокол
                                                        {																			
                                                                if(Packet.Data[35] == 0x08) //приняли echo request
                                                                {
                                                                        Temp = CheckSum_ICMP(&Packet);
                                                                        if(Temp == ((Packet.Data[36] << 8)&0xFF00|Packet.Data[37]))	  //если контрольная сумма ICMP-пакета и вычисленная совпадают, то формируем ответ на него, иначе отбрасываем его
                                                                        {
                                                                                Answear_ICMP(&Packet, ICMP_Packet);
                                                                        }
                                                                        PORTD->RXTX &= 0xF7FF;
                                                                }
                                                                else
                                                                {
                                                                        PORTD->RXTX &= 0xF7FF;
                                                                }
                                                        }
                                                        else
                                                        {
                                                                PORTD->RXTX &= 0xF7FF;
                                                        }
                                                }
                                                else
                                                {
                                                        PORTD->RXTX &= 0xF7FF;
                                                }
                                }
                                else
                                {
                                        PORTD->RXTX &= 0xF7FF;
                                }
                                break;
                }
                //переходим к анализу следующего дескриптора приемника
                RxCurrentDesc.RxCurrentDescriptor++;
                RxCurrentDesc.Number++;
                if(RxCurrentDesc.Number == NUMRXDESC)
                {
                    RxCurrentDesc.RxCurrentDescriptor = RxDescriptor;
                    RxCurrentDesc.Number = 0;	
                }
        } //while(Read_Rx_Descriptor(RxCurrentDescriptor) == 0)
 
        PORTD->RXTX &= 0xF7FF;
}



//***************************************************************************************************
//***************************************************************************************************
//Функция для вычисления контрольной суммы IP-заголовка пакета
//Dt - указатель на пакет
//возвращает контрольную сумму IP-заголовка пакета
unsigned short CheckSum_IP(_ethernet_packet* Dt)
{
        unsigned long Temp, Check = 0;
        for(Temp = 0; Temp < 20; Temp += 2)
        {
                if(Temp == 10) continue;
                else Check += ((Dt->Data[Temp + 14] << 8)&0xFF00)|Dt->Data[Temp + 15];
        }
        Check = (Check >> 16) + (Check & 0xFFFF);
        return (unsigned short)(~Check);
}
//***************************************************************************************************
//***************************************************************************************************
//Функция для вычисления контрольной суммы ICMP-пакета
//Dt - указатель на пакет
//возвращает контрольную сумму ICMP-пакета
unsigned short CheckSum_ICMP(_ethernet_packet* Dt)
{
        unsigned long Temp, Check = 0;
        for(Temp = 0; Temp < Dt->Length - 38; Temp += 2)      //реализовано для пакета ICMP размером до 1450 байт
        {                                                     //Dt->Length - 38,т.к. 34 байта - это Eth2 и IP заголовки, 4 байта - CRС32 Eth2 пакета
                if(Temp == 2) continue;
                else Check += ((Dt->Data[Temp + 34] << 8)&0xFF00)|Dt->Data[Temp + 35];
        }
        Check = (Check >> 16) + (Check & 0xFFFF);
        return (unsigned short)(~Check);
}
//***************************************************************************************************
//***************************************************************************************************
//Функция для считывания принятого пакета
//Dt - указатель на пакет
//возвращает 0, если все данные считаны, 1 - если считан не весь пакет
int Read_Packet(_ethernet_packet* Dt)
{
        unsigned short Temp;
        Temp = ReadRxBufferData(Dt->Data, Dt->Length, Dt->Address);
        if((Dt->Length & 0x0001) == 1)  //если пакет содержит нечетное кол-во байт, то необходимо занулить предпоследний
                                        //считанный байт в буфере, так как там содержится контрольная сумма Eth2 пакета.
        {
                Dt->Data[Dt->Length-5] = 0;
        }
        if(Temp == Dt->Length) return 0;
        else return 1;
}
//***************************************************************************************************
//***************************************************************************************************
//Функция для формирования ответного ARP-пакета
//Dt - указатель на пакет
//возвращает 0
int Answear_ARP(_ethernet_packet* Dt)
{
        unsigned char Send[42];
        unsigned short Temp;

        while(Read_Tx_Descriptor(&TxCurrentDesc)!=0)
		{
			TxCurrentDesc.TxCurrentDescriptor++;
			TxCurrentDesc.Number++;
			if(TxCurrentDesc.Number==NUMTXDESC)
			{
				TxCurrentDesc.Number=0;
				TxCurrentDesc.TxCurrentDescriptor = TxDescriptor;
			}	
		}
		
        //первые 6 байт - удаленный MAC - адрес
        Send[0] = Dt->Remote_MAC[0];
        Send[1] = Dt->Remote_MAC[1];
        Send[2] = Dt->Remote_MAC[2];
        Send[3] = Dt->Remote_MAC[3];
        Send[4] = Dt->Remote_MAC[4];
        Send[5] = Dt->Remote_MAC[5];

        //далее 6 байт - мой MAC-адрес
        Send[6] = My_MAC[1];
        Send[7] = My_MAC[0];
        Send[8] = My_MAC[3];
        Send[9] = My_MAC[2];
        Send[10] = My_MAC[5];
        Send[11] = My_MAC[4];

        //далее заполняем всё так же как в полученном пакете до 19 байта (включительно)
        for(Temp = 12; Temp < 20; Temp++)
        {
                Send[Temp] = Dt->Data[Temp];
        }

        //20 и 21 байты - Opcode: для ответа должен быть равен 2
        Send[21] = 0x00;
        Send[20] = 0x02;

        //с 22 по 27 (включительно) идет мой MAC

        Send[23] = My_MAC[0];
        Send[22] = My_MAC[1];
        Send[25] = My_MAC[2];
        Send[24] = My_MAC[3];
        Send[27] = My_MAC[4];
        Send[26] = My_MAC[5];

        //с 28 по 31 (включительно) идет мой IP

        Send[29] = My_IP[0];
        Send[28] = My_IP[1];
        Send[31] = My_IP[2];
        Send[30] = My_IP[3];

        //с 32 по 37 (включительно) идет удаленный MAC

        Send[32] = Dt->Remote_MAC[0];
        Send[33] = Dt->Remote_MAC[1];
        Send[34] = Dt->Remote_MAC[2];
        Send[35] = Dt->Remote_MAC[3];
        Send[36] = Dt->Remote_MAC[4];
        Send[37] = Dt->Remote_MAC[5];

        //с 38 по 41 (включительно) идет удаленный IP

        Send[38] = Dt->Remote_IP[0];
        Send[39] = Dt->Remote_IP[1];
        Send[40] = Dt->Remote_IP[2];
        Send[41] = Dt->Remote_IP[3];


        WriteTxBufferData(Send,42,TxCurrentDesc.FirstEmptyByte);
        Write_Tx_Descriptor(0x002A,&TxCurrentDesc);     //длина пакета 42 байта
		

 		TxCurrentDesc.TxCurrentDescriptor++;
		TxCurrentDesc.Number++;
		if(TxCurrentDesc.Number==NUMTXDESC)
		{
			TxCurrentDesc.Number=0;
			TxCurrentDesc.TxCurrentDescriptor = TxDescriptor;
		}
#if READSTATUSON
		Packet.CounterTxPacket++;
#endif //READSTATUSON
		return 0;
}
//***************************************************************************************************
//***************************************************************************************************
//Функция для формирования ответного ICMP-пакета
//Dt - указатель на пакет
//возвращает 0
int Answear_ICMP(_ethernet_packet* Dt , unsigned char* ICMP_Packet)
{
        unsigned short Temp;

        while(Read_Tx_Descriptor(&TxCurrentDesc)!=0)	 //ждем свободный дескриптор
		{
			TxCurrentDesc.TxCurrentDescriptor++;
			TxCurrentDesc.Number++;
			if(TxCurrentDesc.Number==NUMTXDESC)
			{
				TxCurrentDesc.Number=0;
				TxCurrentDesc.TxCurrentDescriptor = TxDescriptor;
			}
		}

        //Remote MAC-Address
        ICMP_Packet[0] = Dt->Remote_MAC[0];
        ICMP_Packet[1] = Dt->Remote_MAC[1];
        ICMP_Packet[2] = Dt->Remote_MAC[2];
        ICMP_Packet[3] = Dt->Remote_MAC[3];
        ICMP_Packet[4] = Dt->Remote_MAC[4];
        ICMP_Packet[5] = Dt->Remote_MAC[5];

        //My MAC-Address
        ICMP_Packet[7] = My_MAC[0];
        ICMP_Packet[6] = My_MAC[1];
        ICMP_Packet[9] = My_MAC[2];
        ICMP_Packet[8] = My_MAC[3];
        ICMP_Packet[11] = My_MAC[4];
        ICMP_Packet[10] = My_MAC[5];

        //IP-protocol
        ICMP_Packet[12] = 0x00;
        ICMP_Packet[13] = 0x08;
//Закнчили формировать Eth2-пакет

//Формируем IP-пакет
        //Field of IP-protocol
        for(Temp = 14; Temp < 24; Temp++)
        {
                ICMP_Packet[Temp] = Dt->Data[Temp];
        }
        ICMP_Packet[26] = Dt->Data[30];
        ICMP_Packet[27] = Dt->Data[31];
        ICMP_Packet[28] = Dt->Data[32];
        ICMP_Packet[29] = Dt->Data[33];
        //Remote IP
        ICMP_Packet[30] = Dt->Data[26];
        ICMP_Packet[31] = Dt->Data[27];
        ICMP_Packet[32] = Dt->Data[28];
        ICMP_Packet[33] = Dt->Data[29];

        Temp = CheckSum_IP(Dt);

        //IP CheckSum
        ICMP_Packet[24] = (unsigned char)(Temp >> 8);
        ICMP_Packet[25] = (unsigned char)Temp;

//Закнчили формировать IP-пакет
//Формируем ICMP-пакет
        ICMP_Packet[34] = 0x00; //Echo reply
        ICMP_Packet[35] = 0x00;

        Dt->Data[34] = 0x00;
        Dt->Data[35] = 0x00;

        Temp = CheckSum_ICMP(Dt);
        ICMP_Packet[36] = (unsigned char)(Temp >> 8);
        ICMP_Packet[37] = (unsigned char)Temp;

        for(Temp = 38; Temp < Dt->Length - 4; Temp++)
        {
                ICMP_Packet[Temp] = Dt->Data[Temp];
        }
        if((Dt->Length & 0x0001) == 1)   //если пришел пакет с нечетным кол-ом байт, то необходимо записать в буфер
                                         //на 1 байт больше, чем в пакете, так как расположение байт в буфере: 1,0,3,2,5,4,...
        {
                ICMP_Packet[Dt->Length - 4] = Dt->Data[Dt->Length - 4];
                WriteTxBufferData(ICMP_Packet, Dt->Length - 3, TxCurrentDesc.FirstEmptyByte);
        }
        else
        {
                WriteTxBufferData(ICMP_Packet, Dt->Length - 4, TxCurrentDesc.FirstEmptyByte);
        }
//Закончили формировать ICMP-пакет

        Write_Tx_Descriptor(Dt->Length - 4,&TxCurrentDesc);

		TxCurrentDesc.TxCurrentDescriptor++;
		TxCurrentDesc.Number++;
		if(TxCurrentDesc.Number==NUMTXDESC)
		{
			TxCurrentDesc.Number=0;
			TxCurrentDesc.TxCurrentDescriptor = &TxDescriptor[0];
		}
#if READSTATUSON
		Packet.CounterTxPacket++;
#endif //READSTATUSON
        return 0;
}
//***************************************************************************************************
//***************************************************************************************************
#if READSTATUSON
//Функция для считывания конфигурационных и статусных слов 5600ВГ1У
//Packet - указатель на пакет
void Request_Status(_ethernet_packet* Packet)
{
	Packet->Registr.MAC_CTRL = Read_Word(REG_MAC_CTRL);
	Packet->Registr.MinFrame = Read_Word(REG_MinFrame);
	Packet->Registr.MaxFrame = Read_Word(REG_MaxFrame);
	Packet->Registr.CollConfig = Read_Word(REG_CollConfig);
	Packet->Registr.IPGTx = Read_Word(REG_IPGTx);
	Packet->Registr.MAC_ADDR_T = Read_Word(REG_MAC_ADDR_T);
	Packet->Registr.MAC_ADDR_M = Read_Word(REG_MAC_ADDR_M);
	Packet->Registr.MAC_ADDR_H = Read_Word(REG_MAC_ADDR_H);
	Packet->Registr.HASH0 = Read_Word(REG_HASH0);
	Packet->Registr.HASH1 = Read_Word(REG_HASH1);
	Packet->Registr.HASH2 = Read_Word(REG_HASH2);
	Packet->Registr.HASH3 = Read_Word(REG_HASH3);
	Packet->Registr.INT_MSK = Read_Word(REG_INT_MSK);
	Packet->Registr.INT_SRC = Read_Word(REG_INT_SRC);
	Packet->Registr.PHY_CTRL = Read_Word(REG_PHY_CTRL);
	Packet->Registr.PHY_STAT = Read_Word(REG_PHY_STAT);
	Packet->Registr.RXBF_HEAD = Read_Word(REG_RXBF_HEAD);
	Packet->Registr.RXBF_TAIL = Read_Word(REG_RXBF_TAIL);
	Packet->Registr.STAT_RX_ALL = Read_Word(REG_STAT_RX_ALL);
	Packet->Registr.STAT_RX_OK = Read_Word(REG_STAT_RX_OK);
	Packet->Registr.STAT_RX_OVF = Read_Word(REG_STAT_RX_OVF);
	Packet->Registr.STAT_RX_LOST = Read_Word(REG_STAT_RX_LOST);
	Packet->Registr.STAT_TX_ALL = Read_Word(REG_STAT_TX_ALL);
	Packet->Registr.STAT_TX_OK = Read_Word(REG_STAT_TX_OK);
	Packet->Registr.GCTRL = Read_Word(REG_GCTRL);
}
//***************************************************************************************************
//***************************************************************************************************
//Функция для инициализации конфигурационных и статусных слов 5600ВГ1У
//Packet - указатель на пакет
__inline void InitStatusRegistr(_ethernet_packet* Packet)
{
	Packet->Registr.MAC_CTRL = 0;
	Packet->Registr.MinFrame = 0;
	Packet->Registr.MaxFrame = 0;
	Packet->Registr.CollConfig = 0;
	Packet->Registr.IPGTx = 0;
	Packet->Registr.MAC_ADDR_T = 0;
	Packet->Registr.MAC_ADDR_M = 0;
	Packet->Registr.MAC_ADDR_H = 0;
	Packet->Registr.HASH0 = 0;
	Packet->Registr.HASH1 = 0;
	Packet->Registr.HASH2 = 0;
	Packet->Registr.HASH3 = 0;
	Packet->Registr.INT_MSK = 0;
	Packet->Registr.INT_SRC = 0;
	Packet->Registr.PHY_CTRL = 0;
	Packet->Registr.PHY_STAT = 0;
	Packet->Registr.RXBF_HEAD = 0;
	Packet->Registr.RXBF_TAIL = 0;
	Packet->Registr.STAT_RX_ALL = 0;
	Packet->Registr.STAT_RX_OK = 0;
	Packet->Registr.STAT_RX_OVF = 0;
	Packet->Registr.STAT_RX_LOST = 0;
	Packet->Registr.STAT_TX_ALL = 0;
	Packet->Registr.STAT_TX_OK = 0;
	Packet->Registr.GCTRL = 0;
}
#endif //READSTATUSON
//***************************************************************************************************
//***************************************************************************************************
//Функция для инициализации пакета
//Packet - указатель на пакет
__inline void InitEthPacket(_ethernet_packet* Packet)
{
    Packet->Length = 0;          //Length of receive Data
	Packet->Address = 0;         //Start address of paket in buffer 5600VG1U
//статусные регистры
#if	READSTATUSON
	Packet->CounterTxPacket = 0;
	Packet->CounterRxPacket = 0;
	InitStatusRegistr(Packet);
#endif	//READSTATUSON
}

//Функция для инициализации дескрипторов передатчика
//TxDesc - указатель на структуру организации работы данных с дескрипторами передатчика
void InitTxDescriptor(_tx_current_descriptor* TxDesc)
{
	int Temp;
	TxDesc->TxCurrentDescriptor = TxDescriptor;
	for(Temp=0;Temp<NUMTXDESC;Temp++)
	{
		Write_Word(0x0000,TxDesc->TxCurrentDescriptor->StartAddress);
		TxDesc->TxCurrentDescriptor++;
	}
	TxDesc->TxCurrentDescriptor--;
	TxDesc->TxCurrentDescriptor->LastDesc = 1;
	Write_Word(0x4000,TxDesc->TxCurrentDescriptor->StartAddress);
	
	TxDesc->TxCurrentDescriptor = TxDescriptor;
	TxDesc->Number = 0;
	TxDesc->FirstEmptyByte = 0x1000;
}
//***************************************************************************************************
//***************************************************************************************************
//Функция для инициализации дескрипторов приемника
//RxDesc - указатель на структуру организации работы данных с дескрипторами приемника
void InitRxDescriptor(_rx_current_descriptor* RxDesc)
{
	int Temp;
	RxDesc->RxCurrentDescriptor = RxDescriptor;
	for(Temp=0;Temp<NUMRXDESC;Temp++)
	{
		Ready_Rx_Descriptor(RxDesc->RxCurrentDescriptor); //ready to receive Eth. packet
		RxCurrentDesc.RxCurrentDescriptor++;
	}
	RxDesc->RxCurrentDescriptor--;
	RxDesc->RxCurrentDescriptor->LastDesc = 1;
	Ready_Rx_Descriptor(RxDesc->RxCurrentDescriptor);	//для установки значения 0xE000 (последний дескриптор) в статусном поле дескриптора

	RxDesc->RxCurrentDescriptor = RxDescriptor;
	RxDesc->Number = 0;	
}

//***************************************************************************************************
//***************************************************************************************************
//Функция, выполняющая сброс ПРМ MAC-контроллера
//Параметр:	нет
//Возвращаемых значений нет
void Disable_RX_MAC(void)
{
    Write_Word(0x4200, REG_MAC_CTRL);   //Сброс RX MAC
}

//***************************************************************************************************
//***************************************************************************************************
//Функция, выполняющая инициализацию и разрешение работы ПРМ MAC-контроллера
//Параметр:	нет
//Возвращаемых значений нет
void Enable_RX_MAC(void)
{
    Write_Word(0x07FF, REG_RXBF_HEAD);  // Установка RXBF_HEAD в значение по сбросу
    //Write_Word(0x0000, REG_STAT_RX_OK);
    //Write_Word(0x0000, REG_STAT_RX_OVF);

    ReInitRxDescriptor();  // Переинициализация RX Descriptors
    
    RxCurrentDesc.Number = 0;                          // Установить RX_DESC 0 в качестве текущего дескриптора
	RxCurrentDesc.RxCurrentDescriptor = RxDescriptor;
    
    Write_Word(0x0200, REG_MAC_CTRL);  // Разрешение работы RX MAC
}

//***************************************************************************************************
//***************************************************************************************************
//Функция для переинициализации дескрипторов принимаемых пакетов после сброса ПРМ MAC-контроллера
//Параметр:	нет
//Возвращаемых значений нет
void ReInitRxDescriptor(void)
{
    unsigned int RDesc;
       
    for(Temp=0;Temp<NUMRXDESC;Temp++)
    {
        RDesc = Read_Word(RxCurrentDesc.RxCurrentDescriptor->StartAddress);
        
        if(RDesc & 0x8000) // RX_DESC готов к приёму пакета (RDY == 1)
        {
            return;
        }
        else
        {
            Ready_Rx_Descriptor(RxCurrentDesc.RxCurrentDescriptor);
        }
        RxCurrentDesc.RxCurrentDescriptor++;
    }
}

//***************************************************************************************************

