#ifndef __CONFIG_H_
#define __CONFIG_H_

#ifndef __1986BE91T1_H_
#define __1986BE91T1_H_

#define REG_MAC_CTRL        0x1FC0
#define REG_MinFrame        0x1FC1
#define REG_MaxFrame        0x1FC2
#define REG_CollConfig      0x1FC3
#define REG_IPGTx           0x1FC4
#define REG_MAC_ADDR_T      0x1FC5
#define REG_MAC_ADDR_M      0x1FC6
#define REG_MAC_ADDR_H      0x1FC7
#define REG_HASH0           0x1FC8
#define REG_HASH1           0x1FC9
#define REG_HASH2           0x1FCA
#define REG_HASH3           0x1FCB
#define REG_INT_MSK         0x1FCC
#define REG_INT_SRC         0x1FCD
#define REG_PHY_CTRL        0x1FCE
#define REG_PHY_STAT        0x1FCF
#define REG_RXBF_HEAD       0x1FD0
#define REG_RXBF_TAIL       0x1FD1
#define REG_STAT_RX_ALL     0x1FD4
#define REG_STAT_RX_OK      0x1FD5
#define REG_STAT_RX_OVF     0x1FD6
#define REG_STAT_RX_LOST    0x1FD7
#define REG_STAT_TX_ALL     0x1FD8
#define REG_STAT_TX_OK      0x1FD9
#define REG_GCTRL           0x1FDF

#include "1986be91t1.h"
#include "ethconfig.c"


void EthCfg(void);
void PortConfig(void);
void SPIConfig(void);
void ClkCfg(void);
unsigned short KeyPress(void);

void SPIConfig()
{
		//Set Baud Rate
	//SPI1->SSPx_CPSR = 0x0000000E;  //Prescaler 2, speed: ~2.5 Mbit/s (2.84)
	//SPI1->SSPx_CPSR = 0x00000008;  //Prescaler 2, speed: ~5 Mbit/s
	SPI1->SSPx_CPSR = 0x00000006;  //Prescaler 2, speed: ~7.5 Mbit/s
	//SPI1->SSPx_CPSR = 0x00000004;  //Prescaler 2, speed: ~10 Mbit/s	//��� �������� ��������� 470 �� � ���� SCLK ������ 10 ��� � ���� �� ��������, ������� �������� ������
	//SPI1->SSPx_CPSR = 0x00000002;  //Prescaler 2, speed: ~20 Mbit/s

    	//Word size SPI 8 bits
	SPI1->SSPx_CR0 = 0x00000187;    //SCR = 1; SPH = 1; SPO = 0; SPI Motorola Protocol; Word size 8 bits.
		//Interrupt Disable and Enable Tx and Rx
	SPI1->SSPx_ICR = 0x00000003;    //Clear interrupts flags
    SPI1->SSPx_IMSC = 0;            //SPI Interrupts disable
    SPI1->SSPx_CR1 = 0x00000002;    //Master Mode; Tx and Rx Enable;
    while((SPI1->SSPx_SR & 4) == 4) { Get_Char(); }		//Purge Rx FIFO
}

void PortConfig()
{
//SPI
        PORTB->ANALOG = 0xF800;         //PORTB_11 - PORTF_15: didital pins

        PORTB->PWR = 0xFFC00000;        //PORTB_11 - PORTF_15: max speed edge
		//PORTB->PWR = 0xAA800000;        //PORTB_11 - PORTF_15: high speed edge
		//PORTB->PWR = 0x55400000;        //PORTB_11 - PORTF_15: low speed edge

        PORTB->RXTX = 0x1800;           //SET 11 and 12 BITS OF PORTB
        PORTB->OE = 0x1800;         //PORTB_11,PORTB_12 - OUTPUT
        PORTB->FUNC = 0xA8000000;       //PORTB_13 - PORTF_15: altern. function, PORTB_11, PORTB_12 - PORTS
//����������
        PORTD->RXTX = 0;
        PORTD->OE = 0x00007C00; //PORTD10 - PORTD14 - outputs
        PORTD->FUNC = 0x00000000; //PORTD - ports
        PORTD->ANALOG = 0xFF00; //PORTD - digital
        PORTD->PWR = 0xAAAA0000; //PORTD8 - PORTD15 - fast edge
//������
        PORTC->OE = 0x00000200; 	//PORTC0 - PORTC15 - inputs
        PORTC->FUNC = 0x00000000; 	//PORTC - port
        PORTC->ANALOG = 0xFFFF; 	//PORTC - digital
        PORTC->PWR = 0x1AAC0000; 	//PORTC10 - PORTC14 - fast edge	  PORTC9 - max fast edge (LCD RST = 0 LCD OFF)
		PORTC->RXTX = 0x0000;
}

void ClkCfg()
{
        RST_CLK->HS_CONTROL = 0x00000001;
        while((RST_CLK->CLOCK_STATUS&0x00000004)!=0x00000004){}
		
//PLL On
        RST_CLK->PLL_CONTROL = 0x00000904; // PLL K_mul = 9 (clk = 80 MHz)
        while((RST_CLK->CLOCK_STATUS & 0x00000002) != 0x00000002){} //wait PLL
		EEPROM->CMD = 0x0000018;	//Delay = 3
		RST_CLK->CPU_CLOCK = 0x00000106;

//		RST_CLK->CPU_CLOCK = 0x00000102;  //if PLL OFF
        RST_CLK->PER_CLOCK = 0x21C00110; //��������: PORTB, PORTD, PORTC, PORTF SPI1, RST_CLK
        //RST_CLK->SSP_CLOCK = 0x01000000; //��������: ������������ SSP1
		RST_CLK->SSP_CLOCK = 0x01000000; //��������: ������������ SSP1
}

#define SELECT          0x7800
#define UP              0x7400
#define LEFT            0x6C00
#define RIGHT           0x5C00
#define DOWN            0x3C00
#define NoKeyPress      0x7C00

//-------------------------------------
//--- ������� ��� ������ � �������� ---
//-------------------------------------
void UntilKeyPress(unsigned short x)
{
	while(KeyPress() == x){}  //���� ������� (x) ������, ����
}	
void UntilKeyNotPress(unsigned short x)
{
	while(KeyPress() != x){}  //���� ������� (x) �� ������, ����
}

unsigned short KeyPress()
{
        switch(PORTC->RXTX & 0x7C00)
        {
                case 0x7800: return SELECT;
                case 0x7400: return UP;
                case 0x6C00: return DOWN;
                case 0x5C00: return LEFT;
                case 0x3C00: return RIGHT;
                default: return NoKeyPress;
        }
}

#endif /* __1986BE91T1_H_ */

#endif /*__CONFIG_H_*/

