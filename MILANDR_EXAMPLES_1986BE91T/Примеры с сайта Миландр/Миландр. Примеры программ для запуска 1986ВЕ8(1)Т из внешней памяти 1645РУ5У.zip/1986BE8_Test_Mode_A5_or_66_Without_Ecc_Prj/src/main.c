/**
  ******************************************************************************
  * @file    main.c
  * @author  Milandr Application Team
  * @version V1.3.0
  * @date    21/03/2021
  * @brief   Main program body.
  ******************************************************************************
  * <br><br>
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, MILANDR SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2021 Milandr</center></h2>
  */

#include "MDR1986VE8T.h"
#include "spec.h"
#include "mdr32f8_clkctrl.h"
#include "mdr32f8_port.h"
#include "mdr32f8_ebc.h"

//#define SET_CUSTOM_EBC_WS

#define CUSTOM_EBC_WS_SETUP    1
#define CUSTOM_EBC_WS_ACTIVE   2
#define CUSTOM_EBC_WS_HOLD     1


/*--- This table can help you to create a value to Cfg_0 - Cfg_9 ---*/ 
/*---     (Cfg_x[7:4] is the ECC and Cfg_x[3:0] is the Data)     ---*/
/*
---------------------------------
|Value	|	ECC bits	|	Data bits	|
---------------------------------
|	0x00	|		0000		|		0000		|
|	0x71	|		0111		|		0001		|
|	0xB2	|		1011		|		0010		|
|	0xC3	|		1100		|		0011		|
|	0xD4	|		1101		|		0100		|
|	0xA5	|		1010		|		0101		|
|	0x66	|		0110		|		0110		|
|	0x17	|		0001		|		0111		|
|	0xE8	|		1110		|		1000		|
|	0x99	|		1001		|		1001		|
|	0x5A	|		0101		|		1010		|
|	0x2B	|		0010		|		1011		|
|	0x3C	|		0011		|		1100		|
|	0x4D	|		0100		|		1101		|
|	0x8E	|		1000		|		1110		|
|	0xFF	|		1111		|		1111		|
---------------------------------
*/

/* Config Ext Bus 8 bits, Serial ECC */
const uint8_t Cfg_0 __attribute__((at(0x10000400))) = 0x71;	//Cfg_0[7:4] - ecc, Cfg_0[3:0] - bus mode (1 - 8-bit Ext Bus)
const uint8_t Cfg_1 __attribute__((at(0x10000408))) = 0x71;	//Cfg_1[7:4] - ecc, Cfg_1[3:0] - ecc mode (1 - without ECC)

void BlinkLine(uint32_t Pin);

int main(void)
{
    /* ONLY REV2 MCU, errata 0015. Disable Power-on-Reset control. Hold the SW4 button down until operation complete */
	//POR_disable();
    
#ifdef SET_CUSTOM_EBC_WS
    // Key to access external bus control
	UNLOCK_UNIT (EXT_BUS_CNTR_key);
    EBC_RGNx_WSConfig(RGN0, CUSTOM_EBC_WS_SETUP, CUSTOM_EBC_WS_ACTIVE, CUSTOM_EBC_WS_HOLD);
#endif

	CLK_CNTR->PER0_CLK |= CLKCTRL_PER0_CLK_MDR_PORTC_EN;
    
    PORTC->KEY = _KEY_;
	
	PORTC->SANALOG |= (0xFF << 16);
	PORTC->SOE |= (0xFF << 16);
	PORTC->RXTX = 0;
	PORTC->SPWR[1] |= 0xFFFF;	
	
	while (1) 
	{	
		BlinkLine(PORT_Pin_16);
		BlinkLine(PORT_Pin_17);
		BlinkLine(PORT_Pin_18);
		BlinkLine(PORT_Pin_19);
		BlinkLine(PORT_Pin_20);
		BlinkLine(PORT_Pin_21);
		BlinkLine(PORT_Pin_22);
		BlinkLine(PORT_Pin_23);
	}
}

void BlinkLine(uint32_t Pin)
{
	uint32_t t = 0;
	
	PORTC->SRXTX = Pin;
	for (t=0;t<1000;t++){}
	PORTC->CRXTX = Pin;
	for (t=0;t<1000;t++){}
}
