#ifndef LED_H_
#define LED_H_

#include "stm32f1xx.h"
#include "stm32f1xx_ll_gpio.h"

#define SA LL_GPIO_PIN_8
#define SB LL_GPIO_PIN_9
#define SC LL_GPIO_PIN_10
#define SD LL_GPIO_PIN_11
#define SE LL_GPIO_PIN_12
#define SF LL_GPIO_PIN_13
#define SG LL_GPIO_PIN_14
#define SH LL_GPIO_PIN_15


#define SA_SET LL_GPIO_ResetOutputPin(GPIOB, SA);
#define SA_RESET LL_GPIO_SetOutputPin(GPIOB, SA);
#define SB_SET LL_GPIO_ResetOutputPin(GPIOB, SB);
#define SB_RESET LL_GPIO_SetOutputPin(GPIOB, SB);
#define SC_SET LL_GPIO_ResetOutputPin(GPIOB, SC);
#define SC_RESET LL_GPIO_SetOutputPin(GPIOB, SC);
#define SD_SET LL_GPIO_ResetOutputPin(GPIOB, SD);
#define SD_RESET LL_GPIO_SetOutputPin(GPIOB, SD);
#define SE_SET LL_GPIO_ResetOutputPin(GPIOB, SE);
#define SE_RESET LL_GPIO_SetOutputPin(GPIOB, SE);
#define SF_SET LL_GPIO_ResetOutputPin(GPIOB, SF);
#define SF_RESET LL_GPIO_SetOutputPin(GPIOB, SF);
#define SG_SET LL_GPIO_ResetOutputPin(GPIOB, SG);
#define SG_RESET LL_GPIO_SetOutputPin(GPIOB, SG);
#define SH_SET LL_GPIO_ResetOutputPin(GPIOB, SH);
#define SH_RESET LL_GPIO_SetOutputPin(GPIOB, SH);

void segchar (uint8_t seg);
void ledprint(uint16_t number);

#endif /* LED_H_ */
